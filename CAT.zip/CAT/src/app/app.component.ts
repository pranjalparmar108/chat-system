import {Component, OnInit} from '@angular/core';
import {KeycloakService} from "keycloak-angular";
import {HeaderService} from "./services/header.service";
import {myInfo} from "./models/myInfo.model";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  isLoggedIn : boolean = false;
  myInfo: myInfo | undefined;
  mfaDone: boolean = false;

  constructor(private keyCloakService:KeycloakService,
              private headerService: HeaderService) {}

  async ngOnInit(){
    this.isLoggedIn = await this.keyCloakService.isLoggedIn();

    this.headerService.mfaDoneChanged.subscribe((data: boolean) => {
      this.mfaDone = data;
      // if (this.mfaDone) this.headerService.fetchSideBarData();
    });

    this.headerService.myInfoChanged.subscribe((data: myInfo) => {
      this.myInfo = data;
    });

    if (this.isLoggedIn) {
      this.headerService.getMyInfo();
    }
  }
}
