import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'nameFilter'
})
export class NameFilterPipe implements PipeTransform {
  transform(items: readonly any[], searchText: string): any[] {
    if (!items) {
      return [];
    }
    if (!searchText) {
      return Array.from(items); // Convert readonly array to mutable array
    }
    searchText = searchText.toLowerCase();
    return Array.from(items).filter(item => {
      return item.htmlContent1.toLowerCase().includes(searchText);
    });
  }
}
