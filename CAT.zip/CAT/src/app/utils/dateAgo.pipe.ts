import { Pipe, PipeTransform } from '@angular/core';
import { formatDistanceToNow } from 'date-fns';

@Pipe({
  name: 'dateAgo'
})
export class DateAgoPipe implements PipeTransform {
  transform(value: string): string {
    if (value) {
      const date = new Date(value);
      return formatDistanceToNow(date, { addSuffix: true });
    }
    else return 'Never';
  }
}
