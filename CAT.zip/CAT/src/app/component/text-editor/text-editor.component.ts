declare module 'quill-image-resize-module';
import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import Quill from 'quill';
import BlotFormatter from 'quill-blot-formatter';
import ImageResize from 'quill-image-resize-module';
import ImageCompress from 'quill-image-compress';

@Component({
  selector: 'app-text-editor',
  templateUrl: './text-editor.component.html',
  styleUrls: ['./text-editor.component.scss'],
})
export class TextEditorComponent implements OnInit{
  @Input() htmlContent: string = '';
  @Input() type: string = ''; // text only or image only
  @Input() disabled: boolean = false;
  @Input() placeHolder: string = '';
  @Output() htmlContentUpdated = new EventEmitter<any>();
  editorConfig: any;

  constructor() {
    // Quill.register('modules/blotFormatter', BlotFormatter);
    Quill.register('modules/imageResize', ImageResize);
    Quill.register('modules/imageCompress', ImageCompress);
  }

  ngOnInit(): void {
    if (this.htmlContent !== null || this.htmlContent !== undefined) {
      this.htmlContent = '';
    }
      if (this.type === 'text') {
        this.editorConfig = {
          toolbar: [
            ['bold', 'italic', 'underline', 'strike'],
            [{ indent: '-1' }, { indent: '+1' }],
            [{ align: [] }],
            [{ list: 'ordered' }, { list: 'bullet' }],
            [{ script: 'sub' }, { script: 'super' }],
            [{ direction: 'rtl' }],
            [{ formula: true }],
            ['clean'],
          ],
        };
      } else {
        this.editorConfig = {
          imageResize: {
            displaySize: true,
          },
          imageCompress: {
            quality: 1, // default - 0.7
            maxWidth: 500, // default - 1000
            maxHeight: 125, // default - 1000
            imageType: 'image/jpeg', // default - image/jpeg
            debug: false, // default true
          },
          toolbar: [['image']],
          // blotFormatter: {},
        };
      }
    // if (this.disabled) this.editorConfig = '';
    // console.log(this.editorConfig);
  }

  quillContentUpdated(data:any) {
    this.htmlContentUpdated.emit(data.html);
  }
}
