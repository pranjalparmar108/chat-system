declare module 'quill-image-resize-module';
