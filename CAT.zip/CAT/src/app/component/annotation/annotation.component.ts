import {Component, ElementRef, EventEmitter, Input, OnChanges, OnInit, Output, ViewChild} from '@angular/core';
import {QuestionService} from "../../services/question.service";

@Component({
  selector: 'app-annotation',
  templateUrl: './annotation.component.html',
  styleUrls: ['./annotation.component.scss'],
})
export class AnnotationComponent implements OnInit, OnChanges{
  @Input() preventContextMenu: boolean = false;
  @Input() commentData: any[] = [];
  @Input() annotationReadOnly: boolean = false;
  @Output() saveComment = new EventEmitter<any>();
  @ViewChild('container', { static: true }) container!: ElementRef;
  @Input() hideCommentBubbles: boolean = false;
  points: { x: number; y: number; text: string; isEditable: boolean }[] = [];
  pointsArray: any[] = [];
  activePoint: {
    x: number;
    y: number;
    text: string;
    isEditable: boolean;
  } | null = null;
  showCustomPopup: boolean = false;
  customPopupX: number = 0;
  customPopupY: number = 0;
  mouseX: number = 0;
  mouseY: number = 0;
  constructor(private questionService: QuestionService) {}

  ngOnInit(): void {
    this.questionService.hideCommentsBubbleChanged.subscribe(
      (data) => {
        this.hideCommentBubbles = data;
      });
  }

  ngOnChanges(changes: any) {
    if (changes.commentData?.currentValue.length > 0) {
      // let temp: { x: any; y: any; text: any; isEditable: boolean; }[] = [];
      // changes.commentData.currentValue.forEach((comment: any) => {
      //   temp.push({x: comment.coordinateX, y: comment.coordinateY,  text: comment.comment, isEditable: true});
      //   this.points = temp;
      // });

      this.pointsArray = [];
      const groupedByUser =  changes.commentData.currentValue.reduce((acc: any, comment:any) => {
        const userKey = `${comment.user.firstName} ${comment.user.lastName}`;
        if (!acc[userKey]) {
          acc[userKey] = [];
        }
        acc[userKey].push(comment);
        return acc;
      }, {});
      for( let key in groupedByUser ) {
        let temp: { x: any; y: any; text: any; isEditable: boolean; }[] = [];
        groupedByUser[key].forEach((comment: any) => {
          // if (comment.coordinateY && comment.coordinateX) {
            temp.push({x: comment.coordinateX, y: comment.coordinateY,  text: comment.comment, isEditable: true});
          // }
        });
        this.pointsArray.push(temp);
        console.log(this.pointsArray);
      }
    }
  }

  createPopup(event: MouseEvent): void {
    if (this.preventContextMenu) {
      event.preventDefault();
      const containerRect = this.container.nativeElement.getBoundingClientRect();
      const x = event.clientX - containerRect.left;
      const y = event.clientY - containerRect.top;

      const existingPointIndex = this.points.findIndex(
        (point) => point.x === x && point.y === y
      );

      if (existingPointIndex !== -1) {
        const updatedText = prompt(
          'Update the text for this point:',
          this.points[existingPointIndex].text
        );
        if (updatedText) {
          this.points[existingPointIndex].text = updatedText;
        }
      } else {
        this.customPopupX = x;
        this.customPopupY = y;
        this.showCustomPopup = true;
      }
    }
  }

  saveCustomText(updatedText: string): void {
    if (updatedText) {
      const x = {
        x: this.customPopupX,
        y: this.customPopupY,
        text: updatedText,
        isEditable: true,
      }
      this.points.push(x);
      this.saveComment.emit(x);
    }
    this.showCustomPopup = false;
    this.activePoint = null;
  }

  trackMousePosition(event: MouseEvent): void {
    this.mouseX = event.clientX;
    this.mouseY = event.clientY;

    for (const point of this.points) {
      const distance = Math.sqrt(
        Math.pow(this.mouseX - point.x, 2) + Math.pow(this.mouseY - point.y, 2)
      );

      if (distance <= 16 && point.isEditable) {
        this.activePoint = point;
        return;
      }
    }

    this.activePoint = null;
  }

  activateEditing(point: {
    x: number;
    y: number;
    text: string;
    isEditable: boolean;
  }): void {
    if (point.isEditable) {
      this.activePoint = point;
    }
  }

  deactivateEditing(): void {
    this.activePoint = null;
  }

  saveEditedText(event: any): void {
    if (event.key === 'Enter' && this.activePoint) {
      this.activePoint.isEditable = false;
      this.activePoint = null;
    }
  }
}
