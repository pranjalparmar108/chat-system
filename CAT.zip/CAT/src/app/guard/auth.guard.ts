import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { KeycloakAuthGuard, KeycloakService } from 'keycloak-angular';
import {ToastrService} from "ngx-toastr";

@Injectable({
    providedIn: 'root'
})

export class AppGuard extends KeycloakAuthGuard {

    constructor(protected override router: Router,
                protected override keycloakAngular: KeycloakService,
                public toastr: ToastrService,) {
        super(router, keycloakAngular);
    }

    isAccessAllowed(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean> {
        return new Promise(async (resolve, reject) => {
          if (!this.authenticated) {
            await this.keycloakAngular.login();
            return;
          }
          resolve(true);
        });
    }
}
