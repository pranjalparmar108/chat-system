import {Component, EventEmitter, Input, OnChanges, OnInit, Output} from '@angular/core';
import {HeaderService} from "../../services/header.service";
import {AadhaarService} from "../../services/aadhaar.service";

@Component({
  selector: 'app-aadhaar-esign',
  templateUrl: './aadhaar-esign.component.html',
  styleUrl: './aadhaar-esign.component.scss'
})
export class AadhaarEsignComponent implements OnInit, OnChanges{
  @Input() transactionType: string = '';
  @Output() cancelAadhaarEsign = new EventEmitter<any>();
  @Output() aadhaarESignDone = new EventEmitter<string>();
  part1: boolean = true;
  part2: boolean = false;
  part3: boolean = false;
  part4: boolean = false;
  userAadhaar: string = '';
  aadhaarInput: string = '';
  showAadhaarInputError: boolean = false;
  showAadhaarInputSuccess: boolean = false;
  aadhaarInputError: string = '';
  aadhaarInputSuccess: string = '';
  disableSendOTP: boolean = true;
  sendOTPRefId: string = '';
  disableVerifyOTP: boolean = true;
  aadhaarOTP: string = '';
  aadhaarUserImage: string = '';
  aadhaarESignTransactionId: string = '';
  sendOTPTriggered: boolean = false;
  verifyOTPTriggered: boolean = false;

  constructor(private headerService: HeaderService,
              private aadhaarService: AadhaarService) {}

  ngOnInit(): void {
    this.userAadhaar = this.headerService.myInfo.aadhaar;
  }

  ngOnChanges(changes: any): void {

  }

  openInputAadhar() {
    this.part1 = false;
    this.part2 = true;
    this.part3 = false;
    this.part4 = false;
  }
  openAadharOtp() {
    this.sendOTPTriggered = true;
    this.aadhaarService.sendOTP().subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          if (res.data.code === 200) {
            this.sendOTPRefId = res.data.data.ref_id;
            this.part1 = false;
            this.part2 = false;
            this.part3 = true;
            this.part4 = false;
            this.sendOTPTriggered = false;
          }
        }
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }
  handleCancel() {
    this.part1 = false;
    this.part2 = false;
    this.part3 = false;
    this.part4 = false;
    this.cancelAadhaarEsign.emit(true);
  }

  aadhaarInputChanged() {
    if (this.aadhaarInput.length === 12) {
      if (this.aadhaarInput === this.userAadhaar) {
        this.disableSendOTP = false;
        this.showAadhaarInputError = false;
        this.aadhaarInputError = '';
        this.aadhaarInputSuccess = 'Aadhaar Number validated';
        this.showAadhaarInputSuccess = true;
      } else {
        this.showAadhaarInputError = true;
        this.aadhaarInputError = 'Aadhar Number entered is invalid';
        this.aadhaarInputSuccess = '';
        this.showAadhaarInputSuccess = false;
      }
    } else {
      this.showAadhaarInputError = false;
      this.aadhaarInputError = '';
      this.showAadhaarInputSuccess = false;
      this.aadhaarInputSuccess = '';
    }
  }

  onOTPEnter(data: any) {
    if (data.length === 6) {
      this.aadhaarOTP = data;
      this.disableVerifyOTP = false;
    }
  }

  onVerifyOTP() {
    this.verifyOTPTriggered = true;
    this.aadhaarService.verifyOTP(this.sendOTPRefId, this.aadhaarOTP).subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          if (res.data.code === 200) {
            this.aadhaarUserImage = 'data:image/jpg;base64,' + res.data.data.photo_link;
            this.aadhaarESignTransactionId = res.data.transaction_id;
            this.part4 = true;
            this.part3 = false;
            this.part2 = false;
            this.part1 = false;
            this.verifyOTPTriggered = false;
          }
        }
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }

  onAadhaarESignSuccess() {
    this.aadhaarESignDone.emit(this.transactionType);
    this.part4 = false;
    this.part3 = false;
    this.part2 = false;
    this.part1 = false;
  }
}
