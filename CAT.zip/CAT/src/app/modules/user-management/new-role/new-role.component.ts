import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-new-role',
  templateUrl: './new-role.component.html',
  styleUrl: './new-role.component.scss'
})
export class NewRoleComponent implements OnInit{
  @Input() newRoleModalVisible: boolean = false
  @Output() newRoleSubmit = new EventEmitter<any>();
  newRoleName: any;

  constructor() {
  }

  ngOnInit(): void {

  }

  handleCancel() {
    this.newRoleModalVisible = false;
  }

  handleOk() {
    console.log(this.newRoleName);
    this.newRoleSubmit.emit(this.newRoleName);
  }
}
