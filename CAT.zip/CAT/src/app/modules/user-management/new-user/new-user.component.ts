import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {UserService} from "../../../services/user.service";

@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrl: './new-user.component.scss'
})
export class NewUserComponent implements OnInit{
  @Input() newUserModalVisible: boolean = false;
  @Output() newUserSubmit = new EventEmitter<any>();
  rolesArray: any[] = [];
  newUserData: any;

  constructor(private userService: UserService) {
  }

  ngOnInit(): void {
    this.newUserData = {firstName: '', lastName: '', email: '', phone: '', aadhaar: '', role: '', mfa: true, eSign: true}

    this.getRoles();
  }

  handleCancel() {
    this.newUserModalVisible = false;
  }

  handleOk() {
    this.newUserSubmit.emit(this.newUserData);
  }

  getRoles() {
    this.userService.getRoles().subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          this.rolesArray = res.data;
        }
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }
}
