import {Component, OnInit} from '@angular/core';
import {UserService} from "../../services/user.service";
import {NzMessageService} from "ng-zorro-antd/message";

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrl: './user-management.component.scss'
})
export class UserManagementComponent implements OnInit{
  newUserModalVisible: boolean = false;
  newRoleModalVisible: boolean = false;
  selectedTab: string = '';
  usersData: any[] = [];
  rolesData: any[] = [];

  constructor(private userService: UserService,
              private messageService: NzMessageService) {}

  ngOnInit(): void {
    this.getUsers();
  }

  newUserModalCancel() {
    this.newUserModalVisible = false;
  }

  getUsers() {
    this.selectedTab = 'Users';
    this.userService.getUsers().subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          this.usersData = [...res.data];
        }
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }

  getRoles() {
    this.selectedTab = 'Roles';
    this.userService.getRoles().subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          this.rolesData = res.data;
        }
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }

  onCreateUser() {
    this.newUserModalVisible = true;
  }

  onCreateRole() {
    this.selectedTab = 'Roles';
    this.newRoleModalVisible = true;
  }

  onSubmitNewRole(data: any) {
    this.userService.createRole({name: data}).subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          this.getRoles();
          this.newRoleModalVisible = false;
          this.messageService.create('success', 'Role created successfully');
        }
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }

  onSubmitNewuser(data: any) {
    this.userService.createUser(data).subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          this.messageService.create('success', 'User created successfully');
          this.newUserModalVisible = false;
          this.getUsers();
        } else if (res.statusCode === "409") {
          this.messageService.create('warning', res.statusMessage);
        }
      },
      error: (res: any) => {
        // debugger;
        if (res.statusCode === "409") {
          this.messageService.create('warning', 'User with same email address already exists');
        } else this.messageService.create('error', res.statusMessage);
      }
    });
  }

  onToggleMFA(data: boolean, id: string) {
    this.userService.updateUser(id, {mfaEnabled: data}).subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          if (data) this.messageService.create('success', 'Multi-factor Authentication enabled successfully');
          if (!data) this.messageService.create('success', 'Multi-factor Authentication disabled successfully');
        }
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }

  onToggleESign(data: boolean, id: string) {
    this.userService.updateUser(id, {eSignEnabled: data}).subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          if (data) this.messageService.create('success', 'eSign enabled successfully');
          if (!data) this.messageService.create('success', 'eSign disabled successfully');
        }
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }
}
