import {Component, OnInit} from '@angular/core';
import {MfaService} from "../../services/mfa.service";
import {HeaderService} from "../../services/header.service";
import {KeycloakService} from "keycloak-angular";

@Component({
  selector: 'app-mfa-verify',
  templateUrl: './mfa-verify.component.html',
  styleUrls: ['./mfa-verify.component.css']
})
export class MfaVerifyComponent implements OnInit{
  qrCodeString: string = '';
  verificationCode: string = '';
  intentId: string = '';

  constructor(private mfaService: MfaService,
              private headerService: HeaderService,
              private keycloakAngular: KeycloakService,) {}

  ngOnInit(): void {

    this.mfaService.createIntent({type: 'login'}).subscribe(
      (response: any) => {
        if (response.statusCode === "200") {
          this.qrCodeString = JSON.stringify(response.data.data);
          this.verificationCode = response.data.code;
          this.intentId = response.data.id;
          this.checkIntent();
        }
      },
      (error: any) => {
        console.error('Error fetching details:', error);
      }
    );
  }

  checkIntent() {
    if (this.intentId) {
      this.mfaService.getIntentStatus(this.intentId).subscribe(
        (response: any) => {
          if (response.statusCode === "200") {
            if (response.data.message === 'pending') {
              setTimeout(() => {
                this.checkIntent();
              }, 2000);
            }
            else if (response.data.message === 'success') this.headerService.setMFADone();
          }
        },
        (error: any) => {
          console.error('Error fetching details:', error);
        }
      );
    }
  }

  logout() {
    const x = window.location.href.split("/");
    this.keycloakAngular.logout(x[0] + "/" + x[1] + "/" + x[2]);
  }

  dummyScan() {
    if (this.intentId) {
      this.mfaService.updateIntent(this.intentId, this.verificationCode, {}).subscribe(
        (response: any) => {
        },
        (error: any) => {
          console.error('Error fetching details:', error);
        }
      );
    }
  }
}
