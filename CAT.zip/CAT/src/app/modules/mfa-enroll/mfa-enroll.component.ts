import {Component, computed, Input, OnInit} from '@angular/core';
import {MfaService} from "../../services/mfa.service";
import {HeaderService} from "../../services/header.service";
import {KeycloakService} from "keycloak-angular";

@Component({
  selector: 'app-mfa-enroll',
  templateUrl: './mfa-enroll.component.html',
  styleUrls: ['./mfa-enroll.component.css']
})
export class MfaEnrollComponent implements OnInit{
  invitationId: string | undefined;
  qrCodeString: string = '';
  stage: string = 'getting-started';
  // stage: string = 'completed';
  checkStatus: boolean = false;
  current = 0;

  constructor(private mfaService: MfaService,
              private headerService: HeaderService,
              private keycloakAngular: KeycloakService) {}

  ngOnInit(): void {
      this.headerService.invitationIdChanged.subscribe((data: string) => {
        this.invitationId = data;
        this.fetchDetails();
      });

      this.invitationId = this.headerService.invitationId;
      this.fetchDetails();
  }

  fetchDetails() {
    if (this.invitationId) {
      this.mfaService.getInvitationDetails(this.invitationId).subscribe(
        (response: any) => {
          this.qrCodeString = JSON.stringify(response);
        },
        (error: any) => {
          console.error('Error fetching details:', error);
        }
      );
    }
  }

  onNext(step: string) {
    switch(step) {
      case "getting-started":
      {
        this.stage = 'launch-mobile-app';
        this.current = 1;
        break;
      }
      case "launch-mobile-app":
      {
        this.stage = 'pairing';
        this.current = 2;
        this.checkStatus = true;
        this.getInvitationStatus();
        break;
      }
    }
  }

  onDone() {
    this.logout();
  }

  onPrevious(step: string) {
    switch(step) {
      case "launch-mobile-app":
      {
        this.stage = 'getting-started';
        this.current = 0;
        this.checkStatus = false;
        break;
      }
      case "pairing":
      {
        this.stage = 'launch-mobile-app';
        this.checkStatus = false;
        this.current = 1
        break;
      }
    }
  }

  getInvitationStatus() {
    if (this.invitationId && this.checkStatus) {
      this.mfaService.getInvitationStatus(this.invitationId).subscribe(
        (response: any) => {
          if (response.statusCode === "200") {
            if (response.data.status === 'Sent') {
              setTimeout(() => {
                this.getInvitationStatus();
              }, 2000);
            } else {
              this.checkStatus = false;
              this.stage = 'completed';
              this.checkStatus = false;
              this.current = 3;
            }
          }
        },
        (error: any) => {
          console.error('Error fetching details:', error);
        }
      );
    }
  }

  logout() {
    const x = window.location.href.split("/")
    this.keycloakAngular.logout(x[0] + "/" + x[1] + "/" + x[2]);
  }

  onDummyScan() {
    if (this.invitationId) {
      let body = {
        publicKey: "AAAAB3NzaC1yc2EAAAABJQAAAQB/nAmOjTmezNUDKYvEeIRf2YnwM9/uUG1d0BYsc8/tRtx+RGi7N2lUbp728MXGwdnL9od4cItzky/zVdLZE2cycOa18xBK9cOWmcKS0A8FYBxEQWJ/q9YVUgZbFKfYGaGQxsER+A0w/fX8ALuk78ktP31K69LcQgxIsl7rNzxsoOQKJ/CIxOGMMxczYTiEoLvQhapFQMs3FL96didKr/QbrfB1WT6s3838SEaXfgZvLef1YB2xmfhbT9OXFE3FXvh2UPBfN+ffE7iiayQf/2XR+8j4N4bW30DiPtOQLGUrH1y5X/rpNZNlWW2+jGIxqZtgWg7lTy3mXy5x836Sj/6L",
        deviceId: "7c64d4a9-8465-45c8-9c2d-553649b4d1ac",
      }
      this.mfaService.updateInvitation(this.invitationId, body).subscribe(
        (response: any) => {

        },
        (error: any) => {
          console.error('Error fetching details:', error);
        }
      );
    }
  }
}
