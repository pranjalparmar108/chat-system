import {Component, OnInit} from '@angular/core';
import {InvitationService} from "../../services/invitation.service";
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-invitation',
  templateUrl: './invitation.component.html',
  styleUrls: ['./invitation.component.css']
})
export class InvitationComponent implements OnInit{
  invitationId: string | null = '';
  qrCodeString: string = '';
  stage: string = 'getting-started'

  constructor(private invitationService: InvitationService,
              private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.invitationId = this.route.snapshot.paramMap.get('id');
    if (this.invitationId) {
      this.invitationService.getInvitationDetails(this.invitationId).subscribe(
        (response: any) => {
          console.log(response);
          this.qrCodeString = JSON.stringify(response);
          this.getInvitationStatus();
        },
        (error: any) => {
          console.error('Error fetching details:', error);
        }
      );
    }
  }

  onNext(step: string) {
    switch(step) {
      case "getting-started":
      {
        this.stage = 'launch-mobile-app'
        break;
      }
    }
  }

  getInvitationStatus() {
    if (this.invitationId) {
      this.invitationService.getInvitationStatus(this.invitationId).subscribe(
        (response: any) => {
          console.log(response);
          if (response.status === 'Sent') {
            setTimeout(() => {
              this.getInvitationStatus();
            }, 1000);
          } else this.stage = 'Completed'
        },
        (error: any) => {
          console.error('Error fetching details:', error);
        }
      );
    }
  }
}
