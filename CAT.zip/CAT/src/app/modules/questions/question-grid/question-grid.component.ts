import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import { Router } from '@angular/router';
import {HeaderService} from "../../../services/header.service";

@Component({
  selector: 'app-question-grid',
  templateUrl: './question-grid.component.html',
  styleUrls: ['./question-grid.component.scss'],
})
export class QuestionGridComponent implements OnInit, OnChanges{
  @Input() questionData: any[] = [];
  @Input() searchText: string = '';
  userRole: string = '';
  orignialArray: any[] = [];

  constructor(private router: Router,
              private headerService: HeaderService) {
  }

  ngOnInit() {
    this.userRole = this.headerService.userRole;
  }

  goToBuilder(id: string) {
    if (this.userRole === 'Translator' || this.userRole === 'Vetter' || this.userRole === 'Author') {
      this.router.navigate(['/question-builder'], {queryParams: {id: id}});
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['questionData']?.currentValue) {
      this.orignialArray = this.questionData;
    }
    const searchInput = changes['searchText']?.currentValue;
    if (changes['searchText']?.currentValue) {
      const newArray = this.orignialArray.filter(item => {
        return item.htmlContent1.toLowerCase().includes(searchInput);
      });
      this.questionData = [...newArray];
    } else {
      this.questionData = [...this.orignialArray];
    }
  }
}
