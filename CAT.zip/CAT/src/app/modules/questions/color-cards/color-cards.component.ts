import {Component, OnInit} from '@angular/core';
import {HeaderService} from "../../../services/header.service";
import {environment} from "../../../../environments/environment";
import {HttpClient} from "@angular/common/http";

@Component({
  selector: 'app-color-cards',
  templateUrl: './color-cards.component.html',
  styleUrls: ['./color-cards.component.scss'],
})
export class ColorCardsComponent implements OnInit{
  userRole: string = '';
  cardsArray: any[] = [];

  constructor(private headerService: HeaderService,
              private http: HttpClient) {
  }

  ngOnInit(): void {
    this.userRole = this.headerService.userRole;
    this.populateCardsArray();
    this.updateCardQuestionCounts();
  }

  populateCardsArray() {
    switch(this.userRole) {
      case "Author":
      {
        this.cardsArray.push({name: 'Questions Created', value: 'question-created', cardClass: 'blue', img: 'assets/images/question-created.svg', count: 0, trendingImg: 'assets/images/trending_up.svg', trendingPercentage: '10%'});
        this.cardsArray.push({name: 'Questions Submitted', value: 'question-submitted', cardClass: 'purple', img: 'assets/images/q-submitted.svg', count: 0, trendingImg: 'assets/images/trending_up.svg', trendingPercentage: '10%'});
        this.cardsArray.push({name: 'Reverted Questions', value: 'question-reverted-to-author', cardClass: 'green', img: 'assets/images/revert-ques.svg', count: 0, trendingImg: 'assets/images/trending_down.svg', trendingPercentage: '8%'});
        this.cardsArray.push({name: 'Rejected Questions', value: 'question-rejected', cardClass: 'orange', img: 'assets/images/rejected-ques.svg', count: 0, trendingImg: 'assets/images/trending_up.svg', trendingPercentage: '10%'});
        break;
      }
      case "Evaluator":
      {
        this.cardsArray.push({name: 'Questions Reviewed', value: 'question-evaluated', cardClass: 'blue', img: 'assets/images/question-created.svg', count: 0, trendingImg: 'assets/images/trending_up.svg', trendingPercentage: '10%'});
        this.cardsArray.push({name: 'Questions Reverted', value: 'question-reverted-to-author', cardClass: 'green', img: 'assets/images/revert-ques.svg', count: 0, trendingImg: 'assets/images/trending_down.svg', trendingPercentage: '7%'});
        this.cardsArray.push({name: 'Questions Approved', value: 'question-approved', cardClass: 'purple', img: 'assets/images/question-created.svg', count: 0, trendingImg: 'assets/images/trending_up.svg', trendingPercentage: '10%'});
        this.cardsArray.push({name: 'Rejected Questions', value: 'question-rejected', cardClass: 'orange', img: 'assets/images/rejected-ques.svg', count: 0, trendingImg: 'assets/images/trending_up.svg', trendingPercentage: '10%'});
        break;
      }
      case "Translator":
      {
        this.cardsArray.push({name: 'Questions Submitted', value: 'question-submitted', cardClass: 'purple', img: 'assets/images/q-submitted.svg', count: 0, trendingImg: 'assets/images/trending_up.svg', trendingPercentage: '10%'});
        this.cardsArray.push({name: 'Questions Translated', value: 'question-translated', cardClass: 'purple', img: 'assets/images/question-created.svg', count: 0, trendingImg: 'assets/images/trending_up.svg', trendingPercentage: '6%'});
        this.cardsArray.push({name: 'Questions Reverted', value: 'question-translation-reverted', cardClass: 'green', img: 'assets/images/revert-ques.svg', count: 0, trendingImg: 'assets/images/trending_down.svg', trendingPercentage: '8%'});
        break;
      }
      case "Translator-Evaluator":
      {
        this.cardsArray.push({name: 'Translations Reviewed', value: 'question-translation-approved', cardClass: 'blue', img: 'assets/images/question-created.svg', count: 0, trendingImg: 'assets/images/trending_down.svg', trendingPercentage: '4%'});
        this.cardsArray.push({name: 'Questions Reverted', value: 'question-translation-reverted', cardClass: 'green', img: 'assets/images/revert-ques.svg', count: 0, trendingImg: 'assets/images/trending_down.svg', trendingPercentage: '5%'});
        this.cardsArray.push({name: 'Rejected Questions', value: 'question-rejected', cardClass: 'orange', img: 'assets/images/rejected-ques.svg', count: 0, trendingImg: 'assets/images/trending_up.svg', trendingPercentage: '10%'});
        break;
      }
      case "Vetter":
      {
        this.cardsArray.push({name: 'Total Questions', value: 'question-total', cardClass: 'blue', img: 'assets/images/question-created.svg', count: 0, trendingImg: 'assets/images/trending_up.svg', trendingPercentage: '10%'});
        this.cardsArray.push({name: 'Questions Approved', value: 'question-approved', cardClass: 'purple', img: 'assets/images/question-created.svg', count: 0, trendingImg: 'assets/images/trending_up.svg', trendingPercentage: '10%'});
        this.cardsArray.push({name: 'Questions Translated', value: 'question-translated', cardClass: 'green', img: 'assets/images/question-created.svg', count: 0, trendingImg: 'assets/images/trending_up.svg', trendingPercentage: '10%'});
        this.cardsArray.push({name: 'Rejected Questions', value: 'question-rejected', cardClass: 'orange', img: 'assets/images/rejected-ques.svg', count: 0, trendingImg: 'assets/images/trending_up.svg', trendingPercentage: '10%'});
        break;
      }
    }
  }

  updateCardQuestionCounts() {
    this.cardsArray.forEach((card: any) => {
      this.http.get(`${environment.APIEndpoint}/questions/transactionCount?type=${card.value}`).subscribe({
        next: (res: any) => {
          if (res.statusCode === "200") {
            card.count = res.data;
          }
        },
        error: (e: any) => {
          console.log(e);
        }
      });
    });
  }
}
