import {Component, OnInit} from '@angular/core';
import {HeaderService} from "../../services/header.service";
import {Router} from "@angular/router";
import {QuestionService} from "../../services/question.service";
import {environment} from "../../../environments/environment";
import {HttpClient} from "@angular/common/http";

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.scss'],
})
export class QuestionsComponent implements OnInit {
  newQuestionModalVisible: boolean = false;
  newQuestionInputs = { type: '', subject: '', topic: '', subTopic: '' };
  radioValue = 'A';
  userRole: string = '';
  questionsArray: any[] = [];
  tabsArray: any[] = [];
  searchText: string = '';
  selectedSubject: any;
  selectedTopic: any;

  constructor(
    private headerService: HeaderService,
    private router: Router,
    private questionService: QuestionService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.userRole = this.headerService.userRole;

    this.questionService.questionArrayChanged.subscribe((data: any[]) => {
      this.questionsArray = [...data];
      this.tabsArray.forEach((tab: any) => {
        if (tab.action === this.selectedTabAction) {
          tab.count = this.questionsArray.length;
        }
      });
      console.log(this.questionsArray.length);
    });
    this.setTabsData();
    this.selectTab(this.tabsArray[0].action);
    this.updateCountInTabs();
  }

  showNewQuestionModal() {
    this.newQuestionModalVisible = true;
  }

  newQuestionModalCancel(): void {
    this.newQuestionModalVisible = false;
  }

  newQuestionModalOk() {
    this.questionService.setNewQuestionsInput(this.newQuestionInputs);
    this.router.navigate(['/question-builder'], { queryParams: { id: 'new' } });
  }

  onSelectQuestionType(type: string) {
    this.newQuestionInputs.type = type;
  }

  selectedTabAction: any;
  selectTab(data: any) {
    this.selectedTabAction = data;
    switch (data) {
      case 'In Process': {
        if (this.userRole === 'Author') this.questionService.getAuthorDraftQuestions();
        else if (this.userRole === 'Translator') this.questionService.getTranslationQuestions();
        break;
      }

      case 'Reverted': {
        this.questionService.getAuthorRevertedQuestions();
        break;
      }

      case 'Author-Review': {
        this.questionService.getSubmittedQuestions();
        break;
      }

      case 'Translator-Review': {
        this.questionService.getTranslatorReviewQuestions();
        break;
      }

      case 'Translation': {
        this.questionService.getTranslationQuestions();
        break;
      }

      case 'Vetter-Review': {
        this.questionService.getApprovedTranslationQuestions();
        break;
      }

      case 'Vetter-all-questions': {
        this.questionService.getAllQuestions();
        break;
      }
    }
  }

  setTabsData() {
    switch (this.userRole) {
      case 'Author': {
        this.tabsArray.push(
          { name: 'In Process', action: 'In Process', count: 0 },
          { name: 'Reverted', action: 'Reverted', count: 0 }
        );
        break;
      }

      case 'Evaluator': {
        this.tabsArray.push({
          name: 'In Review',
          action: 'Author-Review',
          count: 0,
        });
        break;
      }

      case 'Translator': {
        this.tabsArray.push(
          { name: 'In Process', action: 'In Process', count: 0 },
          { name: 'Reverted', action: 'Reverted', count: 0 }
        );
        break;
      }

      case 'Translator-Evaluator': {
        this.tabsArray.push({
          name: 'In Review',
          action: 'Translator-Review',
          count: 0,
        });
        break;
      }

      case 'Vetter': {
        this.tabsArray.push({
          name: 'In Review',
          action: 'Vetter-Review',
          count: 0,
        });
        this.tabsArray.push({
          name: 'All Questions',
          action: 'Vetter-all-questions',
          count: 0,
        });
        break;
      }
    }
  }

  updateCountInTabs() {
    this.tabsArray.forEach((tab) => {
      let url;
      if (tab.action === 'In Process' && this.userRole === 'Author') url = 'authorInProcessCount';
      else if (tab.action === 'Reverted' && this.userRole === 'Author') url = 'authorRevertedCount';
      else if (tab.action === 'Author-Review') url = 'evaluatorInReviewCount';
      else if (tab.action === 'In Process' && this.userRole === 'Translator') url = 'translatorInProcessCount';
      else if (tab.action === 'Reverted' && this.userRole === 'Translator') url = 'translatorRevertedCount';
      else if (tab.action === 'Translator-Review') url = 'translatorEvaluatorInReviewCount';
      else if (tab.action === 'Vetter-Review') url = 'vetterInReviewCount';

      this.http.get(`${environment.APIEndpoint}/questions/${url}`).subscribe({
        next: (res: any) => {
          if (res.statusCode === '200') {
            tab.count = res.data;
          }
        },
        error: (e: any) => {
          console.log(e);
        },
      });
    });
  }

  onChangeSubject(event: any) {
    this.subjectsData.forEach((subject: any) => {
      if (subject.subject === event) {
        this.selectedSubject = subject;
      }
    });
  }

  onChangeTopic(event: any) {
    this.selectedSubject.topics.forEach((topic: any) => {
      if (topic.topic === event) {
        this.selectedTopic = topic;
      }
    });
  }

  subjectsData = [
    {
      subject: 'General Intelligence and Reasoning',
      topics: [
        {
          topic: 'Cognitive Skills',
          subtopics: [
            'Analogies',
            'Similarities and differences',
            'Space visualization',
            'Spatial orientation',
            'Problem-solving',
            'Analysis',
            'Judgment',
            'Decision making',
            'Visual memory',
            'Discrimination',
            'Observation',
            'Relationship concepts',
          ],
        },
        {
          topic: 'Logical Reasoning',
          subtopics: [
            'Blood Relations',
            'Arithmetical reasoning',
            'Figural classification',
            'Arithmetic number series',
            'Non-verbal series',
            'Coding and decoding',
            'Statement conclusion',
            'Syllogistic reasoning',
          ],
        },
        {
          topic: 'Visual-Spatial Reasoning',
          subtopics: [
            'Space visualization',
            'Spatial orientation',
            'Visual memory',
            'Figural classification',
            'Non-verbal series',
          ],
        },
      ],
    },
    {
      subject: 'Quantitative Aptitude',
      topics: [
        {
          topic: 'Mathematics Fundamentals',
          subtopics: [
            'Computation of whole numbers',
            'Decimals',
            'Fractions',
            'Relationships between numbers',
            'Square roots',
            'Basic algebraic identities of School Algebra & Elementary surds',
            'Degree and Radian Measures',
            'Standard Identities',
            'Trigonometric ratio',
            'Percentage',
            'Ratio & Proportion',
            'Interest',
            'Averages',
            'Profit and Loss',
            'Discount',
            'Partnership Business',
            'Mixture and Alligation',
          ],
        },
        {
          topic: 'Geometric Figures and Shapes',
          subtopics: [
            'Triangle',
            'Quadrilaterals',
            'Regular Polygons',
            'Right Prism',
            'Right Circular Cone',
            'Right Circular Cylinder',
            'Sphere',
            'Hemispheres',
            'Rectangular Parallelepiped',
            'Regular Right Pyramid with triangular or square base',
          ],
        },
        {
          topic: 'Data Interpretation and Graphs',
          subtopics: [
            'Graphs of Linear Equations',
            'Histogram',
            'Frequency polygon',
            'Bar diagram & Pie chart',
            'Heights and Distances',
            'Relationship with complementary angles',
          ],
        },
        // Add other topics and subtopics under Quantitative Aptitude...
      ],
    },
    {
      subject: 'English Language',
      topics: [
        {
          topic: 'Language Proficiency Group',
          subtopics: [
            'Idioms and Phrases',
            'One word Substitution',
            'Synonyms-Antonyms',
            'Spellings Correction',
            'Fill in the Blanks',
            'Sentence Correction',
            'Error Spotting',
            'Reading Comprehension',
            'Cloze test',
          ],
        },
        {
          topic: 'Grammar and Sentence Structure',
          subtopics: [
            'Active Passive',
            'Sentence Rearrangement',
            'Sentence Improvement',
          ],
        },
      ],
    },
    {
      subject: 'General Awareness',
      topics: [
        {
          topic: 'General Knowledge & Current Affairs',
          subtopics: [
            'India and its neighbouring countries.',
            'Current Affairs',
            'Important Schemes',
            'Important Days',
            'People in News',
          ],
        },
        {
          topic: 'Subject-specific Information',
          subtopics: ['Science', 'Books and Authors', 'Sports'],
        },
        {
          topic: 'Static Knowledge',
          subtopics: ['Portfolio', 'Static GK'],
        },
      ],
    },
    {
      subject: 'Physics',
      topics: [
        {
          topic: 'Classical Mechanics & Basic Physics',
          subtopics: [
            'Physics and Measurement',
            'Kinematics',
            'Laws of Motion',
            'Gravitation',
            'Rotational Motion',
            'Work and Energy',
            'Power',
            'Properties of Solids and Liquids',
          ],
        },
        {
          topic: 'Electricity, Magnetism & Waves',
          subtopics: [
            'Current Electricity',
            'Magnetic Effects of Current',
            'Electronic Devices',
            'Alternating Currents',
            'Electromagnetic Waves',
            'Electromagnetic Induction',
            'Magnetism',
            'Waves',
          ],
        },
        {
          topic: 'Modern Physics & Atomic Theory',
          subtopics: [
            'Optics',
            'Radiation',
            'Dual Nature of Matter',
            'Atoms',
            'Nuclei',
            'Kinetic Theory of Gases',
            'Electrostatics',
          ],
        },
      ],
    },
    {
      subject: 'Chemistry',
      topics: [
        {
          topic: 'Physical Chemistry',
          subtopics: [
            'Some Basic Concepts of Chemistry',
            'States of Matter',
            'Atomic Structure',
            'Chemical Bonding and Molecular Structure',
            'Chemical Thermodynamics',
            'Solutions',
            'Equilibrium',
            'Redox Reactions and Electrochemistry',
            'Chemical Kinetics',
            'Surface Chemistry',
          ],
        },
        {
          topic: 'Organic Chemistry',
          subtopics: [
            'Purification and Characterisation of Organic Compounds',
            'Some Basic Principles of Organic Chemistry',
            'Hydrocarbons',
            'Organic Compounds Containing Halogens',
            'Organic Compounds Containing Oxygen',
            'Organic Compounds Containing Nitrogen',
            'Polymers',
            'Biomolecules',
            'Chemistry in Everyday Life',
            'Principles Related to Practical Chemistry',
          ],
        },
        {
          topic: 'Inorganic Chemistry',
          subtopics: [
            'Classification of Elements and Periodicity in Properties',
            'General Principles and Process of Isolation of Metals',
            'Hydrogen',
            'S Block Elements',
            'P Block Elements',
            'D and F Block Elements',
            'Coordination Compounds',
            'Environmental Chemistry',
          ],
        },
      ],
    },
    {
      subject: 'General Engineering',
      topics: [
        {
          topic: 'Civil Engineering',
          subtopics: [
            'Building Materials',
            'Estimating, Costing and Valuation',
            'Surveying',
            'Soil Mechanics',
            'Hydraulics',
            'Irrigation Engineering',
            'Transportation Engineering',
            'Environmental Engineering',
            'Structural Engineering: Theory of Structures',
            'Concrete Technology',
            'RCC Design',
            'Steel Design',
          ],
        },
        {
          topic: 'Electrical Engineering',
          subtopics: [
            'Basic concepts',
            'Circuit law',
            'Magnetic Circuit',
            'AC Fundamentals',
            'Measurement and Measuring instruments',
            'Electrical Machines',
            'Fractional Kilowatt Motors and single phase induction Motors',
            'Synchronous Machines',
            'Generation',
            'Transmission and Distribution',
            'Estimation and Costing',
            'Utilization and Electrical Energy',
            'Basic Electronic',
          ],
        },
        {
          topic: 'Mechanical Engineering',
          subtopics: [
            'Mechanical Engineering – Theory of Machines and Machine Design',
            'Engineering Mechanics and Strength of Materials',
            'Properties of Pure Substances, 1st Law of Thermodynamics',
            '2nd Law of Thermodynamics, Air standard Cycles for IC Engines',
            'IC Engine Performance',
            'IC Engines Combustion',
            'IC Engine Cooling & Lubrication',
            'Rankine cycle of System, Boilers, Classification, Specification, Fitting & Accessories',
            'Air Compressors & their cycles',
            'Refrigeration cycles, Principle of Refrigeration Plant, Nozzles & Steam Turbines',
            'Properties & Classification of Fluids, Fluid Statics, Measurement of Fluid Pressure',
            'Fluid kinematics, Dynamics of Ideal fluids, Measurement of Flow rate basic principles',
            'Hydraulic Turbines, Centrifugal Pumps, Classification of steels',
          ],
        },
        {
          topic: 'General Intelligence & Reasoning',
          subtopics: [
            'Analogies',
            'Similarities and Differences',
            'Space Visualization',
            'Problem Solving',
            'Analysis',
            'Judgement and Decision Making',
            'Visual Memory',
            'Discrimination',
            'Observation',
            'Relationship Concepts',
            'Arithmetical Reasoning',
            'Verbal and Figure Classification',
            'Arithmetical Number Series',
          ],
        },
      ],
    },
  ];
}
