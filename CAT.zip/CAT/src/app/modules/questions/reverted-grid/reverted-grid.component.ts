import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import { Router } from '@angular/router';
import {HeaderService} from "../../../services/header.service";

@Component({
  selector: 'app-reverted-grid',
  templateUrl: './reverted-grid.component.html',
  styleUrls: ['./reverted-grid.component.scss'],
})
export class RevertedGridComponent implements OnInit, OnChanges{
  @Input() questionData:any[] = [];
  @Input() searchText: string = '';
  data: any[] = [];
  userRole: string = '';
  orignialArray: any[] = [];

  constructor(private headerService: HeaderService,
    private router: Router
  ) {}

  ngOnInit() {
    this.userRole = this.headerService.userRole;
    this.orignialArray = [...this.questionData];
  }
  goToBuilder(id: string) {
    if (this.userRole === 'Translator' || this.userRole === 'Author') {
      this.router.navigate(['/question-builder'], {queryParams: {id: id}});
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['questionData']?.currentValue) {
      this.orignialArray = this.questionData;
    }
    const searchInput = changes['searchText']?.currentValue;
    if (changes['searchText']?.currentValue) {
      const newArray = this.orignialArray.filter(item => {
        return item.htmlContent1.toLowerCase().includes(searchInput);
      });
      this.questionData = [...newArray];
    } else {
      this.questionData = [...this.orignialArray];
    }
  }
}
