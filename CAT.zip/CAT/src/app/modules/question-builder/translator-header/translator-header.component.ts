import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import { Router } from '@angular/router';
import {QuestionService} from "../../../services/question.service";

@Component({
  selector: 'app-translator-header',
  templateUrl: './translator-header.component.html',
  styleUrls: ['./translator-header.component.scss'],
})
export class TranslatorHeaderComponent implements OnInit{
  @Input() questionData: any;
  isVisible = false;
  isChange = false;
  isRevert = false;
  isApprove = false;

  constructor(private router: Router,
              private questionService: QuestionService) {}

  ngOnInit(): void {

  }

  goToHome(): void {
    this.router.navigate(['/dashboard']);
  }

  goToPreview(): void {
    // this.router.navigate(['/preview']);
    this.isVisible = true;
  }

  handleOk(): void {
    this.isVisible = false;
  }

  handleBackClicked(): void {
    console.log('Button cancel clicked!');
    this.isVisible = false;
  }

  saveChanges(): void {
    this.isChange = true;
  }

  handleCancel(): void {
    this.router.navigate(['/questions']);
  }

  approveChanges(): void {
    this.isApprove = true;
  }

  onSubmitTranslation(): void {
    this.isApprove = false;
    this.questionService.setSubmitTranslation(true);
  }

  backApproveChanges(): void {
    this.isApprove = false;
  }

  revertToAuthor(): void {
    this.isRevert = true;
  }

  submitRevertToAuthor(): void {
    this.isRevert = false;
  }

  backRevertToAuthor(): void {
    this.isRevert = false;
  }

  submitChanges() {
    this.questionService.setSubmitTranslation(true);
  }

  onSaveAsDraft() {
    this.questionService.setSaveTranslation(true);
    this.isChange = false;
  }

  onSave() {
    this.questionService.setSaveTranslation(true);
  }
}
