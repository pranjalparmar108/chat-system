import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {HeaderService} from "../../../services/header.service";

@Component({
  selector: 'app-applicable-exam',
  templateUrl: './applicable-exam.component.html',
  styleUrls: ['./applicable-exam.component.scss'],
})
export class ApplicableExamComponent implements OnInit, OnChanges{
  @Input() selectedExams: any[] = [];
  @Output() onSelectApplicableExams = new EventEmitter<any>();
  menuVisible: boolean = false;
  userRole: string = '';
  applicableExams = [
    { label: 'CGL', value: 'CGL', checked: false},
    { label: 'CHSL', value: 'CHSL', checked: false },
    { label: 'STENO C & D', value: 'STENO C & D', checked: false },
    { label: 'CAPF', value: 'CAPF', checked: false},
    { label: 'CONSTABLE-GD', value: 'CONSTABLE-GD', checked: false},
    { label: 'JE', value: 'JE', checked: false},
    { label: 'JHT', value: 'JHT', checked: false},
    { label: 'MTS', value: 'MTS', checked: false},
    { label: 'JSA/LDC', value: 'JSA/LDC', checked: false},
    { label: 'SSA/UDC', value: 'SSA/UDC', checked: false},
  ];

  constructor(private headerService: HeaderService) {}

  ngOnInit(): void {
    this.userRole = this.headerService.userRole;

    this.selectedExams.forEach((a) => {
      this.applicableExams.forEach((b) => {
        if (a.examName === b.label) b.checked = true
      })
    });
  }

  removeItem(index: number) {
    this.applicableExams[index].checked = false;
    this.onSelectApplicableExams.emit(this.applicableExams);
  }

  saveSelection() {
    this.menuVisible = false;
    this.onSelectApplicableExams.emit(this.applicableExams)
  }

  ngOnChanges(changes: any): void {
    changes.selectedExams.currentValue.forEach((a:any) => {
      this.applicableExams.forEach((b) => {
        if (a.examName === b.label) b.checked = true;
      })
    });
  }
}
