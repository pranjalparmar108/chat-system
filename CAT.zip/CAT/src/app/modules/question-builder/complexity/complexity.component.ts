import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-complexity',
  templateUrl: './complexity.component.html',
  styleUrls: ['./complexity.component.scss'],
})
export class ComplexityComponent implements OnInit{

  @Input() selectedGradeLevelPairs: { grade: string; level: string ; duration:string}[] = [];
  @Output() onSelectGradeLevelPair = new EventEmitter<any>();
  gradeOptions: any[] = [];

  ngOnInit(): void {
    this.gradeOptions.push('X');
    this.gradeOptions.push('XII');
    this.gradeOptions.push('Graduate');
  }

  onChooseGradeClick(): void {
    this.selectedGradeLevelPairs.push({ grade: '', level: '' ,duration:''});
  }

  onRemoveGradeClick(index: number): void {
    if (this.selectedGradeLevelPairs[index].grade) this.gradeOptions.push(this.selectedGradeLevelPairs[index].grade);
    this.gradeOptions.sort((a, b) => a - b);
    this.selectedGradeLevelPairs.splice(index, 1);
  }

  onGradeSelectChange(data: string): void {
    this.gradeOptions = this.gradeOptions.filter(item => item !== data);
  }
}
