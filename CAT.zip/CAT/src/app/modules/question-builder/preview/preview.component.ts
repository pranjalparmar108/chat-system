import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.scss'],
})
export class PreviewComponent implements OnInit {
  @Input() questionData: any;
  @Output() backClicked = new EventEmitter<void>();

  constructor() {}

  ngOnInit() {}

  onBackButtonClick() {
    this.backClicked.emit();
  }

  checkForSigleImage() {
    if (this.questionData.type !== 'textImage'){
      let count = 0;
      if(this.questionData.htmlContent21){
        count +=1;
      }
      if(this.questionData.htmlContent22){
        count +=1;
      }
      if(this.questionData.htmlContent23){
        count +=1;
      }
      if(this.questionData.htmlContent24){
        count +=1;
      }
      if(count>1){
        return false
      }else{
        return true
      }
    }else{
      return false
    } 
  }

  radioValue = 'A';
}
