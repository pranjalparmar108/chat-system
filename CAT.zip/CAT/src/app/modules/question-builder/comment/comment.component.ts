import {Component, EventEmitter, Input, OnChanges, OnInit, Output} from '@angular/core';
import {QuestionService} from "../../../services/question.service";

@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.scss']
})
export class CommentComponent implements OnInit, OnChanges{
  @Input() commentsData: any[] = [];
  @Output() commentDeleted = new EventEmitter<boolean>();
  @Output() commentAdded = new EventEmitter<string>();
  commentUsers: any[] = [];
  showCommentBox = false;
  newCommentData: string = '';

  constructor(private questionService: QuestionService) {}
  ngOnInit(): void {
    this.commentUsers = [...new Set(this.commentsData.map(comment => `${comment.user.firstName} ${comment.user.lastName}`))];
  }
  ngOnChanges(changes: any): void {
    if (changes.commentData?.currentValue.length > 0) {
      let x:any[] = changes.commentData?.currentValue;
      this.commentUsers = [...new Set(x.map(comment => `${comment.user.firstName} ${comment.user.lastName}`))];
    }
  }

  deleteComment(index: number) {
    this.questionService.deleteComment(this.commentsData[index].id).subscribe((res: any) => {
      if (res.statusCode === "200") {
        // this.commentsData.splice(index, 1);
        this.commentDeleted.emit(true);
      } else {

      }
    });
  }

  onCommentClick() {
    this.showCommentBox = !this.showCommentBox;
    this.newCommentData = ''
  }

  submitComment(): void {
    this.commentAdded.emit(this.newCommentData);
    this.showCommentBox = !this.showCommentBox;
  }
}
