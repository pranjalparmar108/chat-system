import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';

@Component({
  selector: 'app-audit-log',
  templateUrl: './audit-log.component.html',
  styleUrls: ['./audit-log.component.scss']
})

export class AuditLogComponent implements OnInit, OnChanges{
  @Input() auditData: any[] = [];

  ngOnChanges(changes: SimpleChanges): void {
  }

  ngOnInit(): void {
  }
}
