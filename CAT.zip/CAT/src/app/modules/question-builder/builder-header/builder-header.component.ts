import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-builder-header',
  templateUrl: './builder-header.component.html',
  styleUrls: ['./builder-header.component.scss'],
})
export class BuilderHeaderComponent implements OnInit{
  @Input() questionData: any;
  @Output() onSubmit = new EventEmitter<any>();
  @Output() onSaveDraft = new EventEmitter<any>();
  @Output() onDiscard = new EventEmitter<any>();
  isVisible = false;
  isChange = false;

  constructor(private router: Router) {}

  ngOnInit(): void {

    }

  saveAsDraft(): void {
    this.onSaveDraft.emit();
    // this.router.navigate(['/questions']);
  }
  goToPreview(): void {
    // this.router.navigate(['/preview']);
    this.isVisible = true;
  }
  handleOk(): void {
    console.log('Button ok clicked!');
    this.isVisible = false;
  }

  onSubmitButton() {
    this.onSubmit.emit();
  }

  handleBackClicked(): void {
    console.log('Button cancel clicked!');
    this.isVisible = false;
  }
  saveChanges(): void {
    this.isChange = true;
  }
  handleCancel(): void {
    this.isChange = false;
    this.onDiscard.emit();
  }
}
