import {Component, Input, OnInit} from '@angular/core';
import {QuestionService} from "../../../services/question.service";
import {ToasterService} from "../../../services/toaster.service";
import {Router} from "@angular/router";
import {HeaderService} from "../../../services/header.service";

@Component({
  selector: 'app-translator-view',
  templateUrl: './translator-view.component.html',
  styleUrls: ['./translator-view.component.scss'],
})
export class TranslatorViewComponent implements OnInit {
  @Input() questionData: any;
  questionTranslatedData: any[] = [];
  selectedLanguageIndex = 0;
  previousLanguageIndex = 0;
  autoTranslate: boolean = false;
  userRole: string = '';
  languages = [
    {
      name: 'Hindi',
      img: 'assets/images/language-icon/hindi.svg',
      anuvadiniLang: 'hi-IN',
      google: 'hi',
    },
    {
      name: 'Punjabi',
      img: 'assets/images/language-icon/punjabi.svg',
      anuvadiniLang: 'pa-IN',
      google: 'pa',
    },
    {
      name: 'Bengali',
      img: 'assets/images/language-icon/bengali.svg',
      anuvadiniLang: 'bn-IN',
      google: 'bn',
    },
    {
      name: 'Telugu',
      img: 'assets/images/language-icon/telugu.svg',
      anuvadiniLang: 'te-IN',
      google: 'te',
    },
    {
      name: 'Marathi',
      img: 'assets/images/language-icon/marathi.svg',
      anuvadiniLang: 'mr-IN',
      google: 'mr',
    },
    {
      name: 'Tamil',
      img: 'assets/images/language-icon/tamil.svg',
      anuvadiniLang: 'ta-IN',
      google: 'ta',
    },
    {
      name: 'Urdu',
      img: 'assets/images/language-icon/urdu.svg',
      anuvadiniLang: 'ur-IN',
      google: 'ur',
    },
    {
      name: 'Gujarati',
      img: 'assets/images/language-icon/gujarati.svg',
      anuvadiniLang: 'gu-IN',
      google: 'gu',
    },
    {
      name: 'Kannada',
      img: 'assets/images/language-icon/kannada.svg',
      anuvadiniLang: 'kn-IN',
      google: 'kn',
    },
    {
      name: 'Malayalam',
      img: 'assets/images/language-icon/malayalam.svg',
      anuvadiniLang: 'ml-IN',
      google: 'ml',
    },
    {
      name: 'Odia',
      img: 'assets/images/language-icon/odia.svg',
      anuvadiniLang: 'or-IN',
      google: 'or',
    },
  ];

  constructor(
    private questionService: QuestionService,
    private toasterService: ToasterService,
    private router: Router,
    private headerService: HeaderService
  ) {}

  ngOnInit(): void {
    // this.googleTranslateOAuth();
    this.questionService.submitTranslationChanged.subscribe((data: boolean) => {
      if (data) {
        this.submitTranslation();
      }
    });

    this.questionService.saveTranslationChanged.subscribe((data: boolean) => {
      if (data) {
        this.saveTranslation();
        // this.router.navigate(['/questions']); user will not able to route back after saving translation
      }
    });

    this.languages.forEach((lang) => {
      this.questionTranslatedData.push({
        htmlContent1: '',
        htmlContent3: '',
        language: lang.name,
        answerOptions: [
          { htmlContent: '', sequence: '1', language: lang.name },
          { htmlContent: '', sequence: '2', language: lang.name },
          { htmlContent: '', sequence: '3', language: lang.name },
          { htmlContent: '', sequence: '4', language: lang.name },
        ],
      });
    });
    if (this.questionData?.id) this.selectLanguage(0);
    this.userRole = this.headerService.userRole;
  }

  ngOnChanges(changes: any): void {
    if (this.questionData?.id) this.selectLanguage(0);
  }


  selectLanguage(data: any) {
    this.previousLanguageIndex = this.selectedLanguageIndex;
    this.selectedLanguageIndex = data;
    this.questionService
      .getTranslatedDetails(this.questionData.id, this.languages[data].name)
      .subscribe((response: any) => {
        if (response.statusCode === '200') {
          if (response.data) {
            this.questionTranslatedData[data] = response.data;
            if (this.questionTranslatedData[data].answerOptions.length === 0) {
              this.questionTranslatedData[data].answerOptions = [
                { htmlContent: '', sequence: '1' },
                { htmlContent: '', sequence: '2' },
                { htmlContent: '', sequence: '3' },
                { htmlContent: '', sequence: '4' },
              ];
            }
          }
        }
      });
  }

  onQuestionHTMLContent1Update(index: number, data: any) {
    this.questionTranslatedData[index].htmlContent1 = data;
  }

  onQuestionHTMLContent3Update(index: number, data: any) {
    this.questionTranslatedData[index].htmlContent3 = data;
  }

  onAnswerHTMLContentUpdate(
    questionIndex: number,
    answerIndex: number,
    data: any
  ) {
    this.questionTranslatedData[questionIndex].answerOptions[
      answerIndex
    ].htmlContent = data;
  }

  saveTranslation() {
    this.questionService
      .saveTranslation(
        this.questionData.id,
        this.questionTranslatedData[this.selectedLanguageIndex]
      )
      .subscribe((response: any) => {
        if (response.statusCode === '200') {
          this.toasterService.toasterSuccess(
            'Success',
            this.languages[this.selectedLanguageIndex].name +
              ' Translation saved successfully'
          );
          if (response.data) {
            // this.toasterService.toasterSuccess('Success', 'Translation saved successfully');
          }
        } else this.toasterService.toasterError('Error', response.message);
      });
  }

  submitTranslation() {
    this.questionService
      .saveTranslation(
        this.questionData.id,
        this.questionTranslatedData[this.selectedLanguageIndex]
      )
      .subscribe((response: any) => {
        if (response.statusCode === '200') {
          this.questionService
            .submitTranslation(this.questionData.id)
            .subscribe((res: any) => {
              if (res.statusCode === '200') {
                this.toasterService.toasterSuccess(
                  'Success',
                  'Translation submitted successfully'
                );
                this.router.navigate(['/questions']);
              } else this.toasterService.toasterError('Error', res.message);
            });
        }
      });
  }

  goToAutoTranslate(): void {
    this.autoTranslate = true;
    this.selectedTranslator = '';
  }

  handleOk(): void {
    this.autoTranslate = false;
    this.selectedTranslator = '';
    this.translateOption = 0;
  }

  onSubmit() {
    if (this.selectedTranslator === 'google') {
      this.googleTranslate();
    } else if (this.selectedTranslator === 'anuvadini') {
      this.anuvadiniTranslate();
    } else if (this.selectedTranslator === 'devnagri') {
    }
  }

  anuvadiniTranslate() {
    this.selectedLanguageIndex;
    let body = {
      text: this.questionData.htmlContent1,
      outputLang: this.languages[this.selectedLanguageIndex].anuvadiniLang,
    };
    this.questionService.anuvadini(body).subscribe({
      next: (res: any) => {
        if (res.status === 'success') {
          this.questionTranslatedData[this.selectedLanguageIndex].htmlContent1 =
            res.data;
          if (this.questionData.htmlContent3) {
            let body2 = {
              text: this.questionData.htmlContent3,
              outputLang:
                this.languages[this.selectedLanguageIndex].anuvadiniLang,
            };
            this.questionService.anuvadini(body2).subscribe({
              next: (res: any) => {
                if (res.status === 'success') {
                  this.questionTranslatedData[
                    this.selectedLanguageIndex
                  ].htmlContent3 = res.data;
                  if (this.checkForOption()) {
                    this.translateOptionsAnuvadini();
                  } else {
                    this.handleOk();
                  }
                }
              },
            });
          } else {
            if (this.checkForOption()) {
              this.translateOptionsAnuvadini();
            } else {
              this.handleOk();
            }
          }
        }
      },
    });
  }

  googleTranslate() {
    const formData = new FormData();
    formData.append('key', 'AIzaSyCJ3CmcWX8-9ffw7jbXB-ybCHT2A_Q7DbM');
    formData.append(
      'target',
      this.languages[this.selectedLanguageIndex].google
    );
    if (this.questionData.htmlContent3) {
      formData.append('q', this.questionData.htmlContent1);
      formData.append('q', this.questionData.htmlContent3);
    } else {
      formData.append('q', this.questionData.htmlContent1);
    }
    if (this.checkForOption()) {
      formData.append('q', this.questionData?.answerOptions[0]?.htmlContent);
      formData.append('q', this.questionData?.answerOptions[1]?.htmlContent);
      formData.append('q', this.questionData?.answerOptions[2]?.htmlContent);
      formData.append('q', this.questionData?.answerOptions[3]?.htmlContent);
    }
    this.questionService.googleTranslate(formData).subscribe({
      next: (res: any) => {
        if (this.questionData.htmlContent3) {
          this.questionTranslatedData[this.selectedLanguageIndex].htmlContent1 =
            res.data?.translations[0]?.translatedText;
          this.questionTranslatedData[this.selectedLanguageIndex].htmlContent3 =
            res.data?.translations[1]?.translatedText;
          if (this.checkForOption()) {
            this.questionTranslatedData[
              this.selectedLanguageIndex
            ].answerOptions[0].htmlContent =
              res.data?.translations[2]?.translatedText;
            this.questionTranslatedData[
              this.selectedLanguageIndex
            ].answerOptions[1].htmlContent =
              res.data?.translations[3]?.translatedText;
            this.questionTranslatedData[
              this.selectedLanguageIndex
            ].answerOptions[2].htmlContent =
              res.data?.translations[4]?.translatedText;
            this.questionTranslatedData[
              this.selectedLanguageIndex
            ].answerOptions[3].htmlContent =
              res.data?.translations[5]?.translatedText;
          }
          this.handleOk();
        } else {
          this.questionTranslatedData[this.selectedLanguageIndex].htmlContent1 =
            res.data?.translations[0]?.translatedText;
          if (this.checkForOption()) {
            this.questionTranslatedData[
              this.selectedLanguageIndex
            ].answerOptions[0].htmlContent =
              res.data?.translations[1]?.translatedText;
            this.questionTranslatedData[
              this.selectedLanguageIndex
            ].answerOptions[1].htmlContent =
              res.data?.translations[2]?.translatedText;
            this.questionTranslatedData[
              this.selectedLanguageIndex
            ].answerOptions[2].htmlContent =
              res.data?.translations[3]?.translatedText;
            this.questionTranslatedData[
              this.selectedLanguageIndex
            ].answerOptions[3].htmlContent =
              res.data?.translations[4]?.translatedText;
          }
          this.handleOk();
        }
      },
    });
  }

  selectedTranslator: string = '';
  onSelectTranslator(translator: any) {
    this.selectedTranslator = translator;
  }

  checkForOption() {
    return (
      this.questionData?.answerOptions[0]?.translationRequired ||
      this.questionData?.answerOptions[1]?.translationRequired ||
      this.questionData?.answerOptions[2]?.translationRequired ||
      this.questionData?.answerOptions[3]?.translationRequired
    );
  }

  translateOption: number = 0;
  translateOptionsAnuvadini() {
    let body = {
      text: this.questionData?.answerOptions[this.translateOption]?.htmlContent,
      outputLang: this.languages[this.selectedLanguageIndex].anuvadiniLang,
    };
    this.questionService.anuvadini(body).subscribe({
      next: (res: any) => {
        if (res.status === 'success') {
          this.questionTranslatedData[this.selectedLanguageIndex].answerOptions[
            this.translateOption
          ].htmlContent = res.data;
          this.translateOption += 1;
          if (this.translateOption >= 4) {
            this.handleOk();
          } else {
            this.translateOptionsAnuvadini();
          }
        }
      },
    });
  }
}
