import {Component, EventEmitter, Input, Output} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-vetter-header',
  templateUrl: './vetter-header.component.html',
  styleUrls: ['./vetter-header.component.scss'],
})
export class VetterHeaderComponent {
  @Input() questionData: any
  @Output() revertToAuthorEmitter = new EventEmitter<any>();
  @Output() revertToTranslatorEmitter = new EventEmitter<any>();
  @Output() approveEmitter = new EventEmitter<any>();

  isVisible = false;
  isChange = false;
  isApprove = false;
  isRevert = false;
  isRevertToTranslator: boolean = false;

  constructor(private router: Router) {}

  goToHome(): void {
    this.router.navigate(['/dashboard']);
  }
  goToPreview(): void {
    // this.router.navigate(['/preview']);
    this.isVisible = true;
  }
  handleOk(): void {
    console.log('Button ok clicked!');
    this.isVisible = false;
  }

  handleBackClicked(): void {
    console.log('Button cancel clicked!');
    this.isVisible = false;
  }
  saveChanges(): void {
    this.isChange = true;
  }
  handleCancel(): void {
    this.isChange = false;
    this.router.navigate(['/questions']);
  }

  approveChanges(): void {
    this.isApprove = true;
  }
  submitApproveChanges(): void {
    this.isApprove = false;
    // this.router.navigate(['/dashboard']);
    this.approveEmitter.emit(true);
  }
  backApproveChanges(): void {
    this.isApprove = false;
  }

  revertToAuthor(): void {
    this.isRevert = true;
  }

  revertToTranslator(): void {
    this.isRevertToTranslator = true;
  }
  submitRevertToAuthor(): void {
    this.isRevert = false;
    this.revertToAuthorEmitter.emit(true);
  }

  submitRevertToTranslator() {
    this.isRevertToTranslator = false;
    this.revertToTranslatorEmitter.emit(true);
  }

  backRevertToAuthor(): void {
    this.isRevert = false;
  }

  backRevertToTranslator(): void {
    this.isRevertToTranslator = false;
  }
}
