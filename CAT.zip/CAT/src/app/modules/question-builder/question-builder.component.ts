import {Component, OnInit} from '@angular/core';
import {ToasterService} from "../../services/toaster.service";
import {QuestionService} from "../../services/question.service";
import {ActivatedRoute, Router} from "@angular/router";
import {HeaderService} from "../../services/header.service";
import {NzMessageService} from "ng-zorro-antd/message";
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
// import MathType from '@wiris/mathtype-ckeditor5';
// import { MathType } from '@wiris/mathtype-ckeditor5';
// import '@wiris/mathtype-html-integration-devkit/styles/styles.css';
// import MathType from 'MathType';
// declare module '@wiris/mathtype-ckeditor5' {
//   const MathType: any;
//   export = MathType;
// }
// declare var CKEDITOR: any;
@Component({
  selector: 'app-question-builder',
  templateUrl: './question-builder.component.html',
  styleUrls: ['./question-builder.component.scss'],
})

export class QuestionBuilderComponent implements OnInit {
  public Editor = ClassicEditor;
  
  questionId: string = '';
  correctAnswerOption = 'A';
  userRole: string = '';
  preventContextMenu: boolean = false;
  annotationReadOnly: boolean = false;
  timerRunning = false;
  urlId:string=''
  questionData = {
    type: '',
    subject: '',
    topic: '',
    subTopic: '',
    htmlContent1: '',
    htmlContent21: '',
    htmlContent22: '',
    htmlContent23: '',
    htmlContent24: '',
    htmlContent3: '',
    expiryTimer: '',
    translationRequired1: false,
    translationRequired3: false,
    status: 'Draft',
    answerType: '',
    answerOptions: [
      {
        htmlContent: '',
        translationRequired: false,
        correctAnswer: false,
        sequence: 1,
      },
      {
        htmlContent: '',
        translationRequired: false,
        correctAnswer: false,
        sequence: 2,
      },
      {
        htmlContent: '',
        translationRequired: false,
        correctAnswer: false,
        sequence: 3,
      },
      {
        htmlContent: '',
        translationRequired: false,
        correctAnswer: false,
        sequence: 4,
      },
    ],
    questionExams: [{ examName: '' }],
    questionGrades: [{ grade: '', level: '', duration: '' }],
    questionAudits: [{ createdAt: '' }],
  };
  editorConfig: any = {
    toolbar: [
      ['bold', 'italic', 'underline', 'strike'],
      [{ script: 'sub' }, { script: 'super' }],
      ['clean'],
    ],
  };
  activeTab: string = 'attributes';
  hideCommentBubbles: boolean = false;
  commentsData: any[] = [];
  aadhaarESign: boolean = false;
  aadhaarAuthDone: boolean = false;
  aadhaarESignTransactionType: string = '';

  constructor(
    private toasterService: ToasterService,
    private questionService: QuestionService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private headerService: HeaderService,
    private messageService: NzMessageService
  ) {
  //   ClassicEditor.create( editorElement, {
  //        plugins: [  MathType ],
  //        toolbar: {
  //            items: [
  //                'MathType',
  //                'ChemType',
  //            ]
  //        }
  // })
  // let editorElement
  // if (editorElement) {
  //   ClassicEditor.create(editorElement, {
  //     plugins: [MathType],
  //     toolbar: {
  //       items: ['MathType', 'ChemType']
  //     }
  //   }).catch(error => {
  //     console.error('There was a problem initializing the editor:', error);
  //   });
  //   } else {
  //   console.error('Editor element not found');
  //   }
    

  
  // ClassicEditor
  //   .create( document.querySelector( '#editor' ), {
  //       plugins: [ MathType, /* ... */ ],
  //       toolbar: [ 'MathType', 'ChemType', /* ... */ ]
  //   } )
  //   .then( /* ... */ )
  //   .catch( /* ... */ );

}

  ngOnInit(): void {
    this.userRole = this.headerService.userRole;
    const x = this.questionService.newQuestionsInput;
    this.questionData.type = x.type;
    this.questionData.subject = x.subject;
    this.questionData.topic = x.topic;
    this.questionData.subTopic = x.subTopic;

    this.activatedRoute.queryParams.subscribe((params) => {
      const id = params['id'] ? params['id'] : 'new';
      this.urlId = id;
      if (id === 'new' && !this.questionData.type) {
        this.router.navigate(['/questions']);
      } else this.questionId = id;
      this.fetchQuestionDetails();
      this.startExpiryTimer()
      this.getComments();
    });

    if (
      this.userRole === 'Translator-Evaluator' ||
      this.userRole === 'Translator'
    )
      this.activeTab = 'comments';
  }

  onSelectAnswerType(data: any) {
    this.questionData.answerType = data;
  }

  toggleTab(tab: string) {
    this.activeTab = tab;
    // if (tab === 'comments') this.hideCommentBubbles = false;
    // else if (tab === 'attributes') this.hideCommentBubbles = true;
  }

  onQuestionHTMLContentUpdate1(data: any) {
    this.questionData.htmlContent1 = data;
  }

  onQuestionHTMLContentUpdate21(data: any) {
    this.questionData.htmlContent21 = data;
  }

  onQuestionHTMLContentUpdate22(data: any) {
    this.questionData.htmlContent22 = data;
  }

  onQuestionHTMLContentUpdate23(data: any) {
    this.questionData.htmlContent23 = data;
  }

  onQuestionHTMLContentUpdate24(data: any) {
    this.questionData.htmlContent24 = data;
  }

  onQuestionHTMLContentUpdate3(data: any) {
    this.questionData.htmlContent3 = data;
  }

  onAnswerHTMLContentUpdate0(data: any) {
    this.questionData.answerOptions[0].htmlContent = data;
  }

  onAnswerHTMLContentUpdate1(data: any) {
    this.questionData.answerOptions[1].htmlContent = data;
  }

  onAnswerHTMLContentUpdate2(data: any) {
    this.questionData.answerOptions[2].htmlContent = data;
  }

  onAnswerHTMLContentUpdate3(data: any) {
    this.questionData.answerOptions[3].htmlContent = data;
  }

  onSubmitQuestion() {
    this.aadhaarAuthDone = true;
    if (this.aadhaarAuthDone) {
      this.questionData.status = 'Submitted';
      const correctAnswerOptionIndex = ['A', 'B', 'C', 'D'].indexOf(
        this.correctAnswerOption
      );
      this.questionData.answerOptions[correctAnswerOptionIndex].correctAnswer =
        true;
      this.questionService
        .saveQuestion(this.questionId, this.questionData)
        .subscribe((res: any) => {
          if (res.statusCode === '200') {
            this.messageService.create(
              'success',
              'Question submitted successfully'
            );
            this.toasterService.toasterSuccess(
              'Success',
              'Question submitted successfully'
            );
            this.router.navigate(['/questions']);
          } else {
            this.messageService.create('error', res.statusMessage);
            this.toasterService.toasterError('Error', res.statusMessage);
          }
        });
    } else {
      this.aadhaarESign = true;
      this.aadhaarESignTransactionType = 'submit-question';
    }
  }

  onSaveQuestion() {
    this.questionData.status = 'Draft';
    const correctAnswerOptionIndex = ['A', 'B', 'C', 'D'].indexOf(
      this.correctAnswerOption
    );
    this.questionData.answerOptions[correctAnswerOptionIndex].correctAnswer =
      true;
    this.questionService
      .saveQuestion(this.questionId, this.questionData)
      .subscribe((res: any) => {
        if (res.statusCode === '200') {
          this.messageService.create('success', 'Question saved successfully');
          this.toasterService.toasterSuccess(
            'Success',
            'Question saved successfully'
          );
          // this.router.navigate(['/questions']); after save it will not redirect
        } else {
          this.toasterService.toasterError('Error', res.statusMessage);
          this.messageService.create('error', res.statusMessage);
        }
      });
  }

  fetchQuestionDetails() {
    if (this.questionId && this.questionId !== 'new') {
      this.questionService
        .getQuestionDetails(this.questionId)
        .subscribe((res: any) => {
          if (res.statusCode === '200') {
            this.questionData = res.data;
            if (this.questionData.status === 'Reverted To Author') {
              this.activeTab = 'comments';
              this.preventContextMenu = true;
              this.annotationReadOnly = true;
            }
            this.questionService
              .getQuestionImageData(this.questionId)
              .subscribe((res: any) => {
                if (res.statusCode === '200') {
                  this.questionData.htmlContent21 = res.data.htmlContent21;
                  this.questionData.htmlContent22 = res.data.htmlContent22;
                  this.questionData.htmlContent23 = res.data.htmlContent23;
                  this.questionData.htmlContent24 = res.data.htmlContent24;
                }
              });
            this.questionService
              .getAnswers(this.questionId)
              .subscribe((res: any) => {
                if (res.statusCode === '200') {
                  this.questionData.answerOptions = res.data;
                  this.questionData.answerOptions.forEach((answer, index) => {
                    if (answer.correctAnswer)
                      this.correctAnswerOption = ['A', 'B', 'C', 'D'][index];
                  });
                }
              });
          } else {
          }
        });
    }
  }

  onSelectApplicableExams(data: any) {
    let x: { examName: any }[] = [];
    data.forEach((exam: any) => {
      if (exam.checked) x.push({ examName: exam.label });
    });
    this.questionData.questionExams = x;
  }

  onSelectGradeLevel(data: any) {
    let x: any[] = [];
    data.forEach((y: any) => {
      x.push(y);
    });
    this.questionData.questionExams = x;
  }

  onDiscardChanges() {
    this.router.navigate(['/questions']);
  }

  getComments() {
    if (this.questionId && this.questionId !== 'new') {
      this.questionService
        .getComments(this.questionId)
        .subscribe((res: any) => {
          if (res.statusCode === '200') {
            this.commentsData = res.data;
          } else {
          }
        });
    }
  }

  onSaveComment(data: any) {
    if (data.x && data.y && data.text) {
      const comment = {
        questionId: this.questionId,
        coordinateX: parseInt(data.x),
        coordinateY: parseInt(data.y),
        comment: data.text,
        public: false,
      };

      this.questionService.addComment(comment).subscribe((res: any) => {
        if (res.statusCode === '200') {
          this.getComments();
        } else {
        }
      });
    }
  }

  onCommentDelete(data: boolean) {
    this.getComments();
  }

  onAddComment(data: string) {
    const comment = {
      questionId: this.questionId,
      comment: data,
      public: false,
    };

    this.questionService.addComment(comment).subscribe((res: any) => {
      if (res.statusCode === '200') {
        this.getComments();
      } else {
      }
    });
  }

  onRevertToAuthor() {
    if (this.questionId) {
      this.questionService
        .revertToAuthor(this.questionId)
        .subscribe((res: any) => {
          if (res.statusCode === '200') {
            this.messageService.create(
              'success',
              'Question reverted to Author successfully'
            );
            this.toasterService.toasterSuccess(
              'Success',
              'Question reverted to Author successfully'
            );
            this.router.navigate(['/questions']);
          } else {
          }
        });
    }
  }

  onSubmitEvaluation() {
    if (this.questionId) {
      this.questionService
        .submitEvaluation(this.questionId)
        .subscribe((res: any) => {
          if (res.statusCode === '200') {
            this.messageService.create(
              'success',
              'Question approved successfully'
            );
            this.toasterService.toasterSuccess(
              'Success',
              'Question approved successfully'
            );
            this.router.navigate(['/questions']);
          } else {
          }
        });
    }
  }

  onRevertToTranslator() {
    if (this.questionId) {
      this.questionService
        .revertToTranslator(this.questionId)
        .subscribe((res: any) => {
          if (res.statusCode === '200') {
            this.messageService.create(
              'success',
              'Question reverted to Translator successfully'
            );
            this.toasterService.toasterSuccess(
              'Success',
              'Question reverted to Translator successfully'
            );
            this.router.navigate(['/questions']);
          } else {
          }
        });
    }
  }

  onApproveTranslation() {
    if (this.questionId) {
      this.questionService
        .approveTranslation(this.questionId)
        .subscribe((res: any) => {
          if (res.statusCode === '200') {
            this.messageService.create(
              'success',
              'Question translation approved successfully'
            );
            this.toasterService.toasterSuccess(
              'Success',
              'Question Translation approved successfully'
            );
            this.router.navigate(['/questions']);
          } else {
          }
        });
    }
  }

  onApproveQuestion() {
    if (this.aadhaarAuthDone) {
      if (this.questionId) {
        this.questionService
          .approveQuestion(this.questionId)
          .subscribe((res: any) => {
            if (res.statusCode === '200') {
              this.messageService.create(
                'success',
                'Question approved successfully'
              );
              this.toasterService.toasterSuccess(
                'Success',
                'Question approved successfully'
              );
              this.router.navigate(['/questions']);
            } else {
            }
          });
      }
    } else {
      this.aadhaarESign = true;
      this.aadhaarESignTransactionType = 'approve-question';
    }
  }

  onCancelAadhaarESign() {
    this.aadhaarESign = false;
  }

  onSuccessAadhaarESign(data: any) {
    console.log('transaction type received from aadhaar e-sign', data);
    this.aadhaarESign = false;
    this.aadhaarAuthDone = true;
    if (data === 'submit-question') {
      this.onSubmitQuestion();
      this.aadhaarAuthDone = false;
    } else if (data === 'approve-question') {
      this.onApproveQuestion();
      this.aadhaarAuthDone = false;
    }
  }

  toggleCommentBubble() {
    this.hideCommentBubbles = !this.hideCommentBubbles;
    this.questionService.setHideCommentsBubble(this.hideCommentBubbles);
  }
  isVisible: boolean = false;
  handleDrawingToolModal() {
    this.isVisible = true;
  }

  refreshInterval: number = 1000;
  timerIntervalId: any;
  startExpiryTimer() {
    if (!this.timerRunning) {
      if (this.urlId === 'new') {
        this.questionData.questionAudits[0].createdAt = `${new Date()}`
      }
      this.calculateTimeRemaining();
      this.timerIntervalId = setInterval(() => {
        this.calculateTimeRemaining();
      }, this.refreshInterval);
      this.timerRunning = true;
    }
  }

  calculateTimeRemaining() {
    // debugger
    if (this.questionData?.status === 'Draft' || this.questionData?.status === '') {
      let timeDifference = new Date(this.questionData.questionAudits[0].createdAt).getTime()+43200000 -new Date().getTime();

      if (timeDifference <= 0) {
        // The future date has passed
        this.questionData.expiryTimer = '00:00';
        if (this.questionData.status === 'Draft') {
          // this.questionData.status = 'Expired';
        }
      } else {
        let seconds = Math.floor(timeDifference / 1000);
        let hours = Math.floor(seconds / 3600);
        let minutes = Math.floor((seconds % 3600) / 60);
        let remainingSeconds = seconds % 60;
        this.questionData.expiryTimer = `${this.padWithZeros(
          hours,
          2
        )}:${this.padWithZeros(minutes, 2)}:${this.padWithZeros(
          remainingSeconds,
          2
        )}`;
      }
    }
  }

  padWithZeros(value: number, length: number): string {
    let stringValue = value.toString();
    while (stringValue.length < length) {
      stringValue = '0' + stringValue;
    }
    return stringValue;
  }
}
