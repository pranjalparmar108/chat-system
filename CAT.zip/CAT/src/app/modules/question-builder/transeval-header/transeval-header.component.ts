import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-transeval-header',
  templateUrl: './transeval-header.component.html',
  styleUrls: ['./transeval-header.component.scss'],
})
export class TransevalHeaderComponent implements OnInit{
  @Input() questionData: any
  @Output() revertToTranslator = new EventEmitter<any>();
  @Output() approveTranslation = new EventEmitter<any>();
  isVisible = false;
  isChange = false;
  isRevert = false;
  isApprove = false;

  constructor(private router: Router) {}

  ngOnInit(): void {
  }

  goToHome(): void {
    this.router.navigate(['/questions']);
  }

  goToPreview(): void {
    // this.router.navigate(['/preview']);
    this.isVisible = true;
  }

  handleOk(): void {
    console.log('Button ok clicked!');
    this.isVisible = false;
  }

  handleBackClicked(): void {
    console.log('Button cancel clicked!');
    this.isVisible = false;
  }

  saveChanges(): void {
    this.isChange = true;
    // this.router.navigate(['/questions']);
  }

  handleCancel(): void {
    this.isChange = false;
    this.router.navigate(['/questions']);
  }

  approveChanges(): void {
    this.isApprove = true;
  }

  submitApproveChanges(): void {
    this.isApprove = false;
    this.approveTranslation.emit(true);
    // this.router.navigate(['/dashboard']);
  }

  backApproveChanges(): void {
    this.isApprove = false;
  }

  revertToAuthor(): void {
    this.isRevert = true;
  }

  submitRevertToAuthor(): void {
    this.isRevert = false;
    this.revertToTranslator.emit(true);
  }

  backRevertToAuthor(): void {
    this.isRevert = false;
  }
}
