import {Component, Input, OnChanges, OnInit} from '@angular/core';

@Component({
  selector: 'app-evaluator-view',
  templateUrl: './evaluator-view.component.html',
  styleUrls: ['./evaluator-view.component.scss'],
})
export class EvaluatorViewComponent implements OnInit, OnChanges{
  @Input() questionData: any;
  correctAnswerOption: string = '';
  answerTranslationRequired: boolean = false;
  constructor() {}

  ngOnInit(): void {
    this.questionData.answerOptions.forEach((answer:any, index:number) => {
      if (answer.correctAnswer) this.correctAnswerOption = ["A", "B", "C", "D"][index];
      if (answer.translationRequired) this.answerTranslationRequired = true;
    });
  }

  ngOnChanges(changes: any): void {
    changes.questionData.currentValue?.answerOptions.forEach((answer:any, index:number) => {
      if (answer.correctAnswer) this.correctAnswerOption = ["A", "B", "C", "D"][index];
      if (answer.translationRequired) this.answerTranslationRequired = true;
    });
  }
}
