import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-evaluator-header',
  templateUrl: './evaluator-header.component.html',
  styleUrls: ['./evaluator-header.component.scss'],
})
export class EvaluatorHeaderComponent implements OnInit{
  @Input() questionData: any;
  @Output() revertToAuthor = new EventEmitter<boolean>();
  @Output() submitEvaluation = new EventEmitter<boolean>();
  isVisible = false;
  isChange = false;
  isApprove = false;
  isRevert = false;

  constructor(private router: Router) {}

  ngOnInit(): void {
  }

  goToHome(): void {
    this.router.navigate(['/dashboard']);
  }

  goToPreview(): void {
    // this.router.navigate(['/preview']);
    this.isVisible = true;
  }

  handleOk(): void {
    console.log('Button ok clicked!');
    this.isVisible = false;
  }

  handleBackClicked(): void {
    console.log('Button cancel clicked!');
    this.isVisible = false;
  }

  saveChanges(): void {
    this.isChange = true;
  }

  handleCancel(): void {
    this.isChange = false;
    this.router.navigate(['/questions']);
  }

  approveChanges(): void {
    this.isApprove = true;
  }

  submitApproveChanges(): void {
    this.isApprove = false;
    this.submitEvaluation.emit(true);
    // this.router.navigate(['/dashboard']);
  }

  backApproveChanges(): void {
    this.isApprove = false;
  }

  onRevertToAuthor(): void {
    this.isRevert = true;
  }

  submitRevertToAuthor(): void {
    this.isRevert = false;
    this.revertToAuthor.emit(true);
  }

  backRevertToAuthor(): void {
    this.isRevert = false;
  }
}
