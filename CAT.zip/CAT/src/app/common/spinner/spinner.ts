import { Component } from '@angular/core';
import {SpinnerService} from "../../services/spinner.service";

@Component({
  selector: 'app-spinner',
  template: `<div id="pause" class="d-flex align-items-center justify-content-center" *ngIf="loadingSection">
    <div class="showbox">
      <div class="loader">
        <svg class="circular" viewBox="25 25 50 50">
          <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="4" stroke-miterlimit="10"/>
        </svg>
      </div>
    </div>
  </div>`,
  styleUrls: ['./spinner.scss']
})

export class SpinnerComponent {
  loadingSection: boolean = false;
  constructor(private spinner: SpinnerService){

  }
  ngOnInit(): void {
    this.spinner.isLoading.subscribe((res) => {
      this.loadingSection = res;
    });
  }
}
