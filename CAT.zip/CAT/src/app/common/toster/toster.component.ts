import { Component, OnInit } from '@angular/core';
import {ToastrService} from "ngx-toastr";
import {ToasterService} from "../../services/toaster.service";

@Component({
  selector: 'app-toster',
  templateUrl: './toster.component.html',
  styleUrls: ['./toster.component.scss']
})
export class TosterComponent implements OnInit {
  toasterHeading:any;
  toasterMessage:any;

  constructor(private toaster: ToasterService,
              private toastr: ToastrService){}

  ngOnInit(): void {
    this.toaster.getTriggerSuccess().subscribe({
      next:(res:any)=>{
        if(res){
          // this.openSuccessAlert();
          // setTimeout(()=>{
          //   this.closeSuccessAlert();
          //   },3000);
          console.log('success received', this.toasterHeading, this.toasterMessage);
          this.toastr.success(this.toasterMessage, this.toasterHeading, {
            // progressBar: true,
            timeOut: 3000,
            closeButton: true,
            // disableTimeOut: true,
          });
        }
      }
    });
    this.toaster.getTriggerError().subscribe({
      next:(res:any)=>{
        if(res){
          // this.openNoDocumentErrorAlert()
          // setTimeout(()=>{
          //   this.closeNoDocumentErrorAlert();
          // },3000);
          this.toastr.error(this.toasterMessage, this.toasterHeading, {
            // progressBar: true,
            timeOut: 3000,
            closeButton: true,
          });
        }
      }
    });
    this.toaster.getToasterHeading().subscribe({
      next:(res:any)=>{
        if(res){
          this.toasterHeading = res;
        }
      }
    });
    this.toaster.getToasterMessage().subscribe({
      next:(res:any)=>{
        if(res){
          if(typeof res === 'string'){
            this.toasterMessage = res || '';
          }else{
            this.toasterMessage = TosterComponent.handleErrorMessage(res);
          }
        }
      }
    });
  }

  private static handleErrorMessage(error : any){
    let errorMessage;
    if (error.error && error.error.errors && error.error.errors.length > 0) {
      const errorMessages = error.error.errors.map((err: any) => err.msg);
      errorMessage = errorMessages.join(' ');
    } else if (error.error && typeof error.error === 'string') {
      errorMessage = error.error;
    } else if (error.error && Array.isArray(error.error.error)) {
      const errorMessages = error.error.error.map((err: any) => err.description);
      errorMessage = errorMessages.join(' ');
    } else if (typeof error.error.error === 'object') {
      errorMessage = error.error.error.description || 'Something went wrong';
    }
    return errorMessage;
  }
}
