import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root',
})
export class SharedService {
  constructor(private router: Router) {
    this.userRole = localStorage.getItem(this.storageKey) || '';
  }

  private questionTypeSubject = new BehaviorSubject<string>('text');
  questionType$ = this.questionTypeSubject.asObservable();

  setQuestionType(questionType: string) {
    this.questionTypeSubject.next(questionType);
  }

  // user management
  private storageKey = 'userState';
  private userRole: string = '';

  setInputValue(value: string) {
    if (value === 'evaluator' || value === 'e1') {
      this.userRole = 'Evaluator';
      this.router.navigate(['/dashboard']);
    } else if (value === 'translator' || value === 't1') {
      this.userRole = 'Translator';
      this.router.navigate(['/dashboard']);
    } else if (value === 'translation-evaluator' || value === 'te1') {
      this.userRole = 'Translator-Evaluator';
      this.router.navigate(['/dashboard']);
    } else if (value === 'vetter' || value === 'v1') {
      this.userRole = 'Vetter';
      this.router.navigate(['/dashboard']);
    } else {
      this.userRole = value;
      this.router.navigate(['/get-started']);
    }

    localStorage.setItem(this.storageKey, this.userRole);
  }
  getInputValue() {
    return this.userRole;
  }
  logout() {
    this.userRole = '';
    localStorage.removeItem(this.storageKey);
  }
}
