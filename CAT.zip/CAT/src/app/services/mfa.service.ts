import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MfaService {
  constructor(private http: HttpClient) {}

  getInvitationDetails(id: string | null) {
    return this.http.get<any>(`${environment.APIEndpoint}/invitations/${id}`);
  }

  getInvitationStatus(id: string | null) {
    return this.http.get<any>(`${environment.APIEndpoint}/invitations/${id}/status`);
  }

  updateInvitation(id: string | null, body: any) {
    return this.http.put<any>(`${environment.APIEndpoint}/invitations/${id}`, body);
  }

  createIntent(body: any) {
    return this.http.post<any>(`${environment.APIEndpoint}/intents/`, body);
  }

  getIntentStatus(id: string | null) {
    return this.http.get<any>(`${environment.APIEndpoint}/intents/${id}`);
  }

  updateIntent(id: string | null, code: string, body: any) {
    return this.http.put<any>(`${environment.APIEndpoint}/intents/${id}?code=${code}`, body);
  }
}
