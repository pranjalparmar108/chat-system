import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class InvitationService {
  constructor(
    private http: HttpClient
  ) {}

  getInvitationDetails(id: string | null) {
    return this.http.get<any>(`${environment.APIEndpoint}/invitations/${id}`);
  }

  getInvitationStatus(id: string | null) {
    return this.http.get<any>(`${environment.APIEndpoint}/invitations/${id}/status`);
  }
}
