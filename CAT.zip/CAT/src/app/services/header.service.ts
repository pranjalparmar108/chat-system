import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class HeaderService {
  public userRole: any;
  public myInfo: any;
  public myInfoChanged = new Subject<any>();
  public mfaDone: boolean = false;
  public mfaDoneChanged = new Subject<boolean>();
  public invitationId: string = '';
  public invitationIdChanged = new Subject<string>();

  constructor(private http:HttpClient) { }

  getMyInfo() {
    this.http.get(`${environment.APIEndpoint}/users/myInfo`).subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          this.myInfo = res.data;
          this.userRole = this.myInfo.primaryRole.name;
          if (this.myInfo) {
            this.myInfoChanged.next(this.myInfo);
            if (!this.myInfo.mfaRegistered) this.setInvitationId(this.myInfo.invitationId);
          }
        }
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }

  createEvent(type: string) {
    this.http.post(`${environment.APIEndpoint}/intent`, {type: type}).subscribe({
      next: (res: any) => {
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }

  setMFADone() {
    this.mfaDone = true;
    this.mfaDoneChanged.next(true);
  }

  setInvitationId(data: any) {
    this.invitationId = data
    this.invitationIdChanged.next(data);
  }
}
