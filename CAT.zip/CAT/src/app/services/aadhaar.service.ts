import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AadhaarService {
  constructor(private http: HttpClient) {}

  sendOTP() {
    return this.http.get<any>(`${environment.APIEndpoint}/aadhaar/sendOTP`);
  }

  verifyOTP(id: string, otp: string) {
    return this.http.get<any>(`${environment.APIEndpoint}/aadhaar/verifyOTP?id=${id}&otp=${otp}`);
  }
}
