import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ToasterService {
  private toasterMessage = new Subject<any>();
  private toasterHeading = new Subject<any>();
  private triggerToasterError = new Subject<Boolean>();
  private triggerToasterSuccess = new Subject<Boolean>();
  constructor() { }

  setToasterMessage(message:any){
    this.toasterMessage.next(message);
  }

  getToasterMessage(){
    return this.toasterMessage.asObservable();
  }

  setToasterHeading(message:any){
    this.toasterHeading.next(message);
  }

  getToasterHeading(){
    return this.toasterHeading.asObservable();
  }

  setTriggerSuccess(trigger:Boolean){
    this.triggerToasterSuccess.next(trigger)
  }

  setTriggerError(trigger:Boolean){
    this.triggerToasterError.next(trigger)
  }

  getTriggerSuccess(){
    return this.triggerToasterSuccess.asObservable();
  }

  getTriggerError(){
    return this.triggerToasterError.asObservable();
  }

  toasterSuccess(heading:any,message:any){
    this.setToasterHeading(heading);
    this.setToasterMessage(message);
    this.setTriggerSuccess(true);
  }

  toasterError(heading:any, message : any, location ? : string){
    if(location === 'error'){
      this.setToasterHeading(heading.error.error[0].reason);
      this.setToasterMessage(heading.error.error[0].description);
      this.setTriggerError(true);
    }else{
      this.setToasterHeading(heading);
      this.setToasterMessage(message);
      this.setTriggerError(true);
    }
  }
}
