import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import {BehaviorSubject, Subject} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class QuestionService {
  constructor(private http: HttpClient) {}

  public questionArray :any[]=[];
  public questionArrayChanged = new Subject<any[]>();

  public saveTranslationChanged = new Subject<boolean>();
  public submitTranslationChanged = new Subject<boolean>();

  public hideCommentsBubble :boolean = false;
  public hideCommentsBubbleChanged = new BehaviorSubject<boolean>(false);

  public newQuestionsInput = {
    type: "",
    subject: "",
    topic: "",
    subTopic: ""
  };

  getAuthorDraftQuestions() {
    this.http.get(`${environment.APIEndpoint}/questions/my`).subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          this.setQuestionArray(res.data);
        }
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }

  getAuthorRevertedQuestions() {
    this.http.get(`${environment.APIEndpoint}/questions/myReverted`).subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          this.setQuestionArray(res.data);
        }
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }

  getSubmittedQuestions() {
    this.http.get(`${environment.APIEndpoint}/questions/submitted`).subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          this.setQuestionArray(res.data);
        }
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }

  getTranslatorReviewQuestions() {
    this.http.get(`${environment.APIEndpoint}/questions/translator-review`).subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          this.setQuestionArray(res.data);
        }
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }

  getTranslationQuestions() {
    this.http.get(`${environment.APIEndpoint}/questions/translation`).subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          this.setQuestionArray(res.data);
        }
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }

  getApprovedTranslationQuestions() {
    this.http.get(`${environment.APIEndpoint}/questions/approvedTranslationQuestions`).subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          this.setQuestionArray(res.data);
        }
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }

  getAllQuestions(){
    this.http.get(`${environment.APIEndpoint}/questions/allQuestions`).subscribe({
      next: (res: any) => {
        if (res.statusCode === "200") {
          this.setQuestionArray(res.data);
        }
      },
      error: (e: any) => {
        console.log(e);
      }
    });
  }

  setHideCommentsBubble(data: boolean) {
    this.hideCommentsBubble = data;
    this.hideCommentsBubbleChanged.next(this.hideCommentsBubble);
  }

  setSaveTranslation(data: boolean) {
    this.saveTranslationChanged.next(data);
  }

  setSubmitTranslation(data: boolean) {
    this.submitTranslationChanged.next(data);
  }

  setQuestionArray(data: any) {
    this.questionArray = [...data];
    this.questionArrayChanged.next(this.questionArray);
  }

  setNewQuestionsInput(data: any) {
    this.newQuestionsInput = data;
  }

  saveQuestion(id: string, body: any){
    return this.http.post(`${environment.APIEndpoint}/questions/save?id=${id}`, body);
  }

  getQuestionDetails(id: string){
    return this.http.get(`${environment.APIEndpoint}/questions/getDetails?id=${id}`);
  }

  getQuestionImageData(id: string){
    return this.http.get(`${environment.APIEndpoint}/questions/getQuestionImageData?id=${id}`);
  }

  getAnswers(id: string){
    return this.http.get(`${environment.APIEndpoint}/questions/getAnswers?id=${id}`);
  }

  addComment(body: any){
    return this.http.post(`${environment.APIEndpoint}/questions/addComments`, body);
  }

  revertToAuthor(id: any){
    return this.http.get(`${environment.APIEndpoint}/questions/revertToAuthor?id=${id}`);
  }

  submitEvaluation(id: any){
    return this.http.get(`${environment.APIEndpoint}/questions/submitEvaluation?id=${id}`);
  }

  deleteComment(id: string){
    return this.http.get(`${environment.APIEndpoint}/questions/deleteComment?id=${id}`);
  }

  getComments(id: string,){
    return this.http.get(`${environment.APIEndpoint}/questions/getComments?id=${id}`);
  }

  getTranslatedDetails(id: string, lang: string){
    return this.http.get(`${environment.APIEndpoint}/questions/getTranslatedDetails?id=${id}&lang=${lang}`);
  }

  saveTranslation(id: string, body: any){
    return this.http.post(`${environment.APIEndpoint}/questions/saveTranslation?id=${id}`, body);
  }

  submitTranslation(id: string){
    return this.http.get(`${environment.APIEndpoint}/questions/submitTranslation?id=${id}`);
  }

  revertToTranslator(id: string){
    return this.http.get(`${environment.APIEndpoint}/questions/revertToTranslator?id=${id}`);
  }

  approveTranslation(id: string){
    return this.http.get(`${environment.APIEndpoint}/questions/approveTranslation?id=${id}`);
  }

  approveQuestion(id: string){
    return this.http.get(`${environment.APIEndpoint}/questions/approveQuestion?id=${id}`);
  }

  anuvadini(body:any){
    return this.http.post(`https://chatapi.aicte-india.org/text-to-text`,body);
  }

  googleTranslate(body:any){
    return this.http.post(`https://translation.googleapis.com/language/translate/v2`,body);
  }

  // googleTranslateOauth(body:any){
  //   return this.http.post(
  //     `https://accounts.google.com/o/oauth2/v2/auth?client_id=304708842-l4fqpbk2jedvtqq7aveo0b9qviuq8kr2.apps.googleusercontent.com&response_type=token&redirect_uri=http://localhost:4201&scope=https://www.googleapis.com/auth/cloud-translation`,
  //     body
  //   );
  // }
}
