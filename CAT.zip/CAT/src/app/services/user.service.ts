import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import {BehaviorSubject} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private http: HttpClient) {}

  getUsers() {
    return this.http.get<any>(`${environment.APIEndpoint}/users/all`);
  }

  getRoles() {
    return this.http.get<any>(`${environment.APIEndpoint}/users/roles`);
  }

  createRole(body: any) {
    return this.http.post<any>(`${environment.APIEndpoint}/users/createRole`, body);
  }

  createUser(body: any) {
    return this.http.post<any>(`${environment.APIEndpoint}/users/create`, body);
  }

  updateUser(id: string, body: any) {
    return this.http.put<any>(`${environment.APIEndpoint}/users/update?id=${id}`, body);
  }

  uploadProfile(body: any) {
    return this.http.post<any>(`${environment.APIEndpoint}/users/uploadProfile`, body);
  }
}
