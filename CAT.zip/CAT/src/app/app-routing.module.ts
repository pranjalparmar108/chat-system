import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {AppGuard} from "./guard/auth.guard";
import {QuestionsComponent} from "./modules/questions/questions.component";
import {QuestionBuilderComponent} from "./modules/question-builder/question-builder.component";
import {UserManagementComponent} from "./modules/user-management/user-management.component";

const routes: Routes = [
  { path: 'questions', component: QuestionsComponent, canActivate: [AppGuard]},
  { path: 'question-builder', component: QuestionBuilderComponent, canActivate: [AppGuard]},
  { path: 'user-management', component: UserManagementComponent, canActivate: [AppGuard]},
  { path: '**', component: QuestionsComponent, canActivate: [AppGuard]},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
