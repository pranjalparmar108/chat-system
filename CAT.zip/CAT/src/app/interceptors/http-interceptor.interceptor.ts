import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { finalize } from "rxjs/operators";
import { SpinnerService } from "../services/spinner.service";

@Injectable()
export class HttpInterceptorInterceptor implements HttpInterceptor {
  constructor(private spinner:SpinnerService) {
  }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    const myInfoRegex = /\/api\/v1\/intents/;
    const invitationRegex = /\/api\/v1\/invitations/;
    const regex = /^https:\/\/translation\.googleapis\.com\/language\/translate\/v2*$/;
    if (!myInfoRegex.test(request.url) && !invitationRegex.test(request.url)) {
      this.spinner.show();
    }
    if (regex.test(request.url)) {
     request = request.clone({
       headers: request.headers.delete('Authorization'),
     });
    }
    return next.handle(request).pipe(finalize(() => {this.spinner.hide() }));
  }
}
