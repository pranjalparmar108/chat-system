import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { catchError, Observable, retry, throwError } from "rxjs";
import {ToasterService} from "../services/toaster.service";

@Injectable()
export class ErrorInterceptorInterceptor implements HttpInterceptor {
  constructor(private router: Router, private toasterService: ToasterService) {
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      retry(1),
      catchError((e: HttpErrorResponse) => {
        if (e.error.error === "jwt expired") {
          this.toasterService.toasterError('Session expired','please login again to continue your work');
          sessionStorage.removeItem("CLST");
          sessionStorage.removeItem("checkLogin");
          this.router.navigate(["/login"]);

        } else if (e.error.error === "invalid-access") {
          this.toasterService.toasterError('You do not have permission to perform this action','please ask admin for the permission');
          if (this.router.url === "/login") {
            sessionStorage.removeItem("CLST");
            sessionStorage.removeItem("checkLogin");
            window.location.reload();
          }
        }
        return throwError(() => new Error());
      })
    );
  }
}
