import { NgModule, APP_INITIALIZER } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import {AppRoutingModule} from "./app-routing.module";
import {QRCodeModule} from "angularx-qrcode";
import {initializer} from "./utils/app-init";
import {KeycloakAngularModule, KeycloakService} from "keycloak-angular";
import {AppGuard} from "./guard/auth.guard";
import {SpinnerComponent} from "./common/spinner/spinner";
import {HeaderComponent} from "./layouts/header/header.component";
import {CommonModule, registerLocaleData} from "@angular/common";
import { MfaEnrollComponent } from './modules/mfa-enroll/mfa-enroll.component';
import { MfaVerifyComponent } from './modules/mfa-verify/mfa-verify.component';
// nz modules
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzImageModule } from 'ng-zorro-antd/image';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzSpaceModule } from 'ng-zorro-antd/space';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzTypographyModule } from 'ng-zorro-antd/typography';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzCheckboxModule } from 'ng-zorro-antd/checkbox';
import { NzTagModule } from 'ng-zorro-antd/tag';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzUploadModule } from 'ng-zorro-antd/upload';
import { NzStepsModule } from 'ng-zorro-antd/steps';
import { NZ_I18N } from 'ng-zorro-antd/i18n';
import { en_US } from 'ng-zorro-antd/i18n';
import { QuillModule } from 'ngx-quill';
import en from '@angular/common/locales/en';
import { QuestionsComponent } from './modules/questions/questions.component';
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import { QuestionBuilderComponent } from './modules/question-builder/question-builder.component';
import {BuilderHeaderComponent} from "./modules/question-builder/builder-header/builder-header.component";
import {EvaluatorHeaderComponent} from "./modules/question-builder/evaluator-header/evaluator-header.component";
import {TransevalHeaderComponent} from "./modules/question-builder/transeval-header/transeval-header.component";
import {TranslatorHeaderComponent} from "./modules/question-builder/translator-header/translator-header.component";
import {VetterHeaderComponent} from "./modules/question-builder/vetter-header/vetter-header.component";
import {AnnotationComponent} from "./component/annotation/annotation.component";
import {LogoComponent} from "./component/logo/logo.component";
import {TextEditorComponent} from "./component/text-editor/text-editor.component";
import {ApplicableExamComponent} from "./modules/question-builder/applicable-exam/applicable-exam.component";
import {AuditLogComponent} from "./modules/question-builder/audit-log/audit-log.component";
import {CommentComponent} from "./modules/question-builder/comment/comment.component";
import {ComplexityComponent} from "./modules/question-builder/complexity/complexity.component";
import {PreviewComponent} from "./modules/question-builder/preview/preview.component";
import {EvaluatorViewComponent} from "./modules/question-builder/evaluator-view/evaluator-view.component";
import {TranslatorViewComponent} from "./modules/question-builder/translator-view/translator-view.component";
import {VetterViewComponent} from "./modules/question-builder/vetter-view/vetter-view.component";
import {ColorCardsComponent} from "./modules/questions/color-cards/color-cards.component";
import {QuestionListComponent} from "./modules/questions/question-list/question-list.component";
import {QuestionGridComponent} from "./modules/questions/question-grid/question-grid.component";
import {RevertedGridComponent} from "./modules/questions/reverted-grid/reverted-grid.component";
import {RevertedListComponent} from "./modules/questions/reverted-list/reverted-list.component";
import {ReviewListComponent} from "./modules/questions/review-list/review-list.component";
import {ReviewGridComponent} from "./modules/questions/review-grid/review-grid.component";
import {DateAgoPipe} from "./utils/dateAgo.pipe";
import {AutosizeModule} from "ngx-autosize";
import {ToastrModule} from "ngx-toastr";
import {TosterComponent} from "./common/toster/toster.component";
import {ErrorInterceptorInterceptor} from "./interceptors/error-interceptor.interceptor";
import {HttpInterceptorInterceptor} from "./interceptors/http-interceptor.interceptor";
import {AadhaarEsignComponent} from "./modules/aadhaar-esign/aadhaar-esign.component";
import {NgOtpInputModule} from "ng-otp-input";
import {UserManagementComponent} from "./modules/user-management/user-management.component";
import {NzMessageModule} from "ng-zorro-antd/message";
import {NewUserComponent} from "./modules/user-management/new-user/new-user.component";
import {NewRoleComponent} from "./modules/user-management/new-role/new-role.component";
import {NameFilterPipe} from "./utils/questionName.pipe";
// import {MathliveBlot} from "./component/text-editor/mathlive-blot"
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';

registerLocaleData(en);


@NgModule({
  declarations: [
    AppComponent,
    SpinnerComponent,
    HeaderComponent,
    TosterComponent,
    MfaEnrollComponent,
    MfaVerifyComponent,
    QuestionsComponent,
    QuestionBuilderComponent,
    BuilderHeaderComponent,
    EvaluatorHeaderComponent,
    TransevalHeaderComponent,
    TranslatorHeaderComponent,
    VetterHeaderComponent,
    AnnotationComponent,
    LogoComponent,
    TextEditorComponent,
    ApplicableExamComponent,
    AuditLogComponent,
    CommentComponent,
    ComplexityComponent,
    PreviewComponent,
    EvaluatorViewComponent,
    TranslatorViewComponent,
    VetterViewComponent,
    ColorCardsComponent,
    QuestionListComponent,
    QuestionGridComponent,
    RevertedGridComponent,
    RevertedListComponent,
    ReviewListComponent,
    ReviewGridComponent,
    DateAgoPipe,
    AadhaarEsignComponent,
    UserManagementComponent,
    NewUserComponent,
    NewRoleComponent,
    NameFilterPipe,
  ],
    imports: [
        CommonModule,
        BrowserModule,
        FormsModule,
        HttpClientModule,
        BrowserAnimationsModule,
        ReactiveFormsModule,
        AppRoutingModule,
        QRCodeModule,
        KeycloakAngularModule,
        // nz modules
        NzButtonModule,
        NzCardModule,
        NzGridModule,
        NzSpaceModule,
        NzMenuModule,
        NzDropDownModule,
        NzIconModule,
        NzImageModule,
        NzLayoutModule,
        NzTableModule,
        NzDividerModule,
        NzTabsModule,
        NzTypographyModule,
        NzInputModule,
        NzRadioModule,
        NzSelectModule,
        NzModalModule,
        NzCheckboxModule,
        NzTagModule,
        NzSwitchModule,
        NzUploadModule,
        NzStepsModule,
        QuillModule.forRoot(),
        AutosizeModule,
        ToastrModule,
        ToastrModule.forRoot(),
      NgOtpInputModule,
      NzMessageModule,
      CKEditorModule 
    ],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: initializer,
      deps: [ KeycloakService ],
      multi: true
    },
    AppGuard,
    // MathliveBlot,
    {provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorInterceptor, multi: true,},
    {provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptorInterceptor,multi: true,},
    { provide: NZ_I18N, useValue: en_US }],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule { }
