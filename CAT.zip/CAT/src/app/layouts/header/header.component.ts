import {Component, OnInit} from '@angular/core';
import { HeaderService } from '../../services/header.service';
import { KeycloakService } from "keycloak-angular";
import { Location } from '@angular/common';
import {NzUploadChangeParam} from "ng-zorro-antd/upload";
import {UserService} from "../../services/user.service";
import {NavigationExtras, Router} from "@angular/router";

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})

export class HeaderComponent implements OnInit {
  myInfo: any;
  headerArray: any[] = [];

  constructor(private keycloakAngular: KeycloakService,
              private headerService: HeaderService,
              private locationService: Location,
              private userService: UserService,
              private router: Router) {
  }

  ngOnInit() {
    this.myInfo = this.headerService.myInfo;
    this.populateHeaderArray();
    this.updateCurrentSelection();
  }

  populateHeaderArray() {
    switch(this.myInfo.primaryRole) {
      default: {
        this.headerArray.push({displayName: "Questions", navigateTo: "/question", iconImg: "assets/images/questionsIcon.svg", selected: true});
        this.headerArray.push({displayName: "User Management", navigateTo: "/user-management", iconImg: "assets/images/userIcon.svg", selected: false});
        break;
      }
    }
  }

  updateCurrentSelection() {
    const currentURL = this.locationService.path().split('?')[0].split('-')[0];
    const currentURL1 = this.locationService.path().split('?')[0];
    if (currentURL) {
      this.headerArray.forEach((header) => {
        header.selected = header.navigateTo === currentURL || header.navigateTo === currentURL1;
      });
    }
  }

  onLogout() {
    const x = window.location.href.split("/");
    this.keycloakAngular.logout(x[0] + "/" + x[1] + "/" + x[2]);
  }

  onClickUploadProfilePhoto() {
    const fileInput = window.document.querySelector('#profile-photo-upload-from-header input[type="file"]');
    if (fileInput instanceof HTMLInputElement) {
      fileInput.click();
    }
  }

  onProfileImageChange(event: NzUploadChangeParam) {
    const file: File = event.file.originFileObj as File;
    const formData = new FormData();
    formData.append('file', file);
    this.userService.uploadProfile(formData).subscribe((res) => {
      if (res.statusCode === "200") {
        const body = {profilePhotoPath: "https://cat.cubastion.net/" + res.data.filePath};
        this.userService.updateUser(this.myInfo.id, body).subscribe((res) => {
          if (res.statusCode === "200") {
            this.myInfo.profilePhotoPath = "https://cat.cubastion.net/" + res.data.filePath;
          }
        });
      }
    });
  }

  reloadPage(route: string) {
    const currentUrl = this.router.url;

    if (currentUrl === route) {
      const extras: NavigationExtras = {
        skipLocationChange: true,
      };

      this.router.navigateByUrl('/', extras).then(() => {
        this.router.navigate([route]);
      });
    }
  }
}
