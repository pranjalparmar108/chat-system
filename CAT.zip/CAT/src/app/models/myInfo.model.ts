export interface myInfo {
  id: string;
  firstName:string;
  lastName:string;
  email:string;
  phone:string;
  aadhaar:string;
  mfaEnabled:boolean;
  mfaRegistered:boolean;
  eSignEnabled:boolean;
  invitationId:string;
  orgId:string;
  profilePhoto:string;
  status:string;
}
