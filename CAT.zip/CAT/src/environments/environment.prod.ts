export const environment = {
  production: true,
  APIEndpoint : 'https://cat.cubastion.net/api/v1',
  keycloak: {
    issuer: 'https://catauth.cubastion.net',
    realm: 'caf',
    clientId: '03cc4411-cf86-485a-ae21-37cb85423ace',
  }
};
